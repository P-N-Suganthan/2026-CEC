function results = main(maxFE, problemIds)
%MAIN Run RDE-SOR on the ten CEC 2026 bound-constrained MOPs.
%
%   main() runs MaOP1--MaOP10 with the official budget of 100000 function
%   evaluations per problem.
%
%   main(maxFE) overrides the budget for smoke testing.
%
%   main(maxFE, problemIds) selects problem indices. Set the PLATEMO_ROOT
%   environment variable to the directory containing platemo.m before
%   launching MATLAB.

    if nargin < 1 || isempty(maxFE)
        maxFE = 100000;
    end
    if nargin < 2 || isempty(problemIds)
        problemIds = 1:10;
    end

    entryDir = fileparts(mfilename('fullpath'));
    repoRoot = fileparts(fileparts(entryDir));
    benchmarkRoot = fullfile(repoRoot, 'benchmark', 'CEC2026_BC_MOP_M3_D7');
    algorithmRoot = fullfile(entryDir, 'Algorithm');

    outputRoot = fullfile(repoRoot, 'outputs');
    if ~isfolder(outputRoot)
        mkdir(outputRoot);
    end

    platemoRoot = getenv('PLATEMO_ROOT');
    if ~isempty(platemoRoot)
        if ~isfile(fullfile(platemoRoot, 'platemo.m'))
            error('RDE_SOR:InvalidPlatEMO', ...
                'PLATEMO_ROOT does not contain platemo.m: %s', platemoRoot);
        end
        addpath(genpath(platemoRoot));
    end
    if isempty(which('platemo'))
        error('RDE_SOR:MissingPlatEMO', ...
            'Set PLATEMO_ROOT to a PlatEMO directory containing platemo.m.');
    end

    addpath(genpath(algorithmRoot));
    addpath(fullfile(benchmarkRoot, 'MaOP'));

    requiredSymbols = {'RDE_SOR', 'MaOP1', 'MaOP10', 'pdist2'};
    for i = 1:numel(requiredSymbols)
        if isempty(which(requiredSymbols{i}))
            error('RDE_SOR:MissingDependency', ...
                'Required MATLAB symbol is unavailable: %s', requiredSymbols{i});
        end
    end

    validateattributes(maxFE, {'numeric'}, {'scalar', 'integer', 'positive'});
    validateattributes(problemIds, {'numeric'}, ...
        {'vector', 'integer', '>=', 1, '<=', 10});

    problems = {@MaOP1, @MaOP2, @MaOP3, @MaOP4, @MaOP5, ...
                @MaOP6, @MaOP7, @MaOP8, @MaOP9, @MaOP10};
    previousDir = pwd;
    restoreDir = onCleanup(@() cd(previousDir)); %#ok<NASGU>
    results = repmat(struct( ...
        'problem', '', 'maxFE', maxFE, 'elapsedSeconds', 0, ...
        'populationSize', 0, 'objectiveCount', 0, 'outputFile', ''), ...
        1, numel(problemIds));

    for k = 1:numel(problemIds)
        problemId = problemIds(k);
        problemName = sprintf('MaOP%d', problemId);
        fprintf('Running RDE-SOR on %s with maxFE=%d...\n', problemName, maxFE);
        started = tic;
        [decs, objs, cons] = platemo( ...
            'algorithm', @RDE_SOR, ...
            'problem', problems{problemId}, ...
            'N', 100, 'M', 3, 'D', 7, ...
            'maxFE', maxFE, 'save', 0);
        elapsedSeconds = toc(started);

        if isempty(objs) || size(objs, 2) ~= 3
            error('RDE_SOR:InvalidOutput', ...
                '%s returned an invalid objective matrix.', problemName);
        end

        outputFile = fullfile(outputRoot, sprintf( ...
            'RDE_SOR_%s_M3_D7_FE%d.mat', problemName, maxFE));
        save(outputFile, 'decs', 'objs', 'cons', 'maxFE', ...
            'problemName', 'elapsedSeconds');

        results(k).problem = problemName;
        results(k).elapsedSeconds = elapsedSeconds;
        results(k).populationSize = size(objs, 1);
        results(k).objectiveCount = size(objs, 2);
        results(k).outputFile = outputFile;
        fprintf('Completed %s: %d solutions, %.2f seconds.\n', ...
            problemName, size(objs, 1), elapsedSeconds);
    end
end
