classdef RDE_SOR < ALGORITHM
% RDE-SOR combines directional selection, archive-assisted search, and stable output selection.

    methods
        function main(Algorithm,Problem)
            epsilon = Algorithm.ParameterSet(0.05);

            Popul = Problem.Initialization();
            [Population,N,frontState] = SelectionRootAdaptive(Popul,Problem.N,0,epsilon);
            Population2 = Population;
            [Archive,archiveState] = ArchiveMemory2026('update',Population,Population,3 * Problem.N,epsilon);
            StablePop = [];
            stableState = frontState;
            OutputPopulation = Population;
            polished = false;
            nextArchiveFE = 0.58 * Problem.maxFE;
            nextInjectFE  = 0.54 * Problem.maxFE;
            nextRefineFE  = 0.72 * Problem.maxFE;
            nextRepairFE  = 0.58 * Problem.maxFE;
            stallCounter = 0;
            prevState = frontState;

            while Algorithm.NotTerminated(OutputPopulation)
                progress = Problem.FE / Problem.maxFE;
                eliteProb = 0.45 + 0.20 * max(progress - 0.60,0) + 0.10 * min(max(stallCounter - 1,0),2);
                eliteProb = min(0.85, max(0.45, eliteProb));
                useEliteBranch = Problem.FE >= Problem.maxFE*0.5 && rand() < eliteProb;
                unevenBoost = min(0.18, 0.22 * max(frontState.nnCV - 0.35, 0));
                doExplore = rand() < min(0.98, max(0.70, 0.92 - 0.18 * progress + unevenBoost));
                if useEliteBranch
                    if doExplore
                        NewPopulation = Exploration2026(Problem,Population,Popul,N,Problem.N);
                    else
                        NewPopulation = [];
                    end
                    Population2 = EnvironmentalSelectionFast([Population2,NewPopulation],Problem.N,epsilon);
                    Fitness2 = CalFitnessFast(Population2.objs,epsilon);
                    MatingPool = TournamentSelection(2,Problem.N,-Fitness2);
                    highSpanState = isfield(frontState,'spanRatio') && frontState.spanRatio >= 2.50;
                    useDiversityDE = frontState.nnCV > 0.52 && ...
                        (progress < 0.82 || (progress < 0.90 && highSpanState));
                    if useDiversityDE
                        NewPopul = OperatorDE2026(Problem,Population2(MatingPool),-Fitness2(MatingPool));
                    else
                        NewPopul = OperatorElite2026(Problem,Population2(MatingPool),Archive,-Fitness2(MatingPool),progress,frontState);
                    end
                    Population2 = EnvironmentalSelectionFast([Population2,NewPopul],Problem.N,epsilon);
                else
                    if doExplore
                        NewPopulation = Exploration2026(Problem,Population,Popul,N,Problem.N);
                    else
                        NewPopulation = [];
                    end
                    Popul = EnvironmentalSelectionFast([Popul,NewPopulation],Problem.N,epsilon);
                    Fitness1 = CalFitnessFast(Popul.objs,epsilon);
                    MatingPool = TournamentSelection(2,Problem.N,-Fitness1);
                    NewPopul = OperatorDE2026(Problem,Popul(MatingPool),-Fitness1(MatingPool));
                    Popul = EnvironmentalSelectionFast([Popul,NewPopul],Problem.N,epsilon);
                end

                RefinedPopulation = [];
                MemoryPopulation = [];
                RepairPopulation = [];
                if Problem.FE >= nextRefineFE && ...
                        (progress >= 0.72 && (frontState.nnCV < 0.45 || stallCounter >= 1 || frontState.needsPolish))
                    RefinedPopulation = EliteRefine2026(Problem,[Population,Population2],Archive,epsilon,progress,frontState);
                    nextRefineFE = nextRefineFE + 0.10 * Problem.maxFE;
                end
                if Problem.FE >= nextInjectFE
                    MemoryPopulation = ArchiveMemory2026('reinject',Problem,Archive,Population,progress,frontState,archiveState,stallCounter);
                    nextInjectFE = nextInjectFE + 0.12 * Problem.maxFE;
                end
                if Problem.FE >= nextRepairFE && (frontState.nnCV > 0.50 || stallCounter >= 1)
                    RepairPopulation = CoverageRepair2026(Problem,Population,Archive,progress,frontState,stallCounter);
                    nextRepairFE = nextRepairFE + 0.10 * Problem.maxFE;
                end

                merged = [Population,NewPopul,NewPopulation,Population2,RefinedPopulation,MemoryPopulation,RepairPopulation];
                [Population,N,newState] = SelectionRootAdaptive(merged,Problem.N,progress,epsilon);
                stateDelta = abs(newState.nnCV - prevState.nnCV) + abs(newState.frontRatio - prevState.frontRatio);
                if stateDelta < 0.03
                    stallCounter = stallCounter + 1;
                else
                    stallCounter = 0;
                end
                if Problem.FE >= nextArchiveFE && (newState.nnCV > 0.42 || stallCounter >= 2 || progress >= 0.88)
                    [Archive,archiveState] = ArchiveMemory2026('update',Archive,[Population,Population2,RefinedPopulation,MemoryPopulation,RepairPopulation],3 * Problem.N,epsilon);
                    nextArchiveFE = nextArchiveFE + 0.06 * Problem.maxFE;
                end
                if ~polished && newState.needsPolish
                    [Population,N] = SelectionExactFast([merged,Archive,Popul],Problem.N);
                    polished = true;
                end
                [StablePop,stableState,OutputPopulation] = StableOutput2026(StablePop,stableState,Population,newState,progress);
                OutputPopulation = OutputSidecar2026(OutputPopulation,merged,Problem.N,progress,epsilon);
                frontState = newState;
                prevState = newState;
                Population2 = Population;
            end
        end
    end
end
