function [Fitness,I,C] = CalFitnessFast(PopObj,kappa)
% Vectorized indicator-based fitness calculation.

    N = size(PopObj,1);
    fmin = min(PopObj,[],1);
    fmax = max(PopObj,[],1);
    span = fmax - fmin;
    span(span == 0) = 1;
    PopObj = (PopObj - fmin) ./ span;

    diffTensor = permute(PopObj,[1 3 2]) - permute(PopObj,[3 1 2]);
    I = max(diffTensor,[],3);
    C = max(abs(I),[],1);
    C(C == 0) = 1;
    Fitness = sum(-exp(-I./C/kappa),1) + 1;
end
