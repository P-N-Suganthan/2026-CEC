function Offspring = CoverageRepair2026(Problem,Population,Archive,progress,frontState,stallCounter)
% Conservative coverage repair for late-stage local deterioration.
% It perturbs sparse objective-space representatives in decision space using
% local archive and population scales.

    if isempty(Population) || progress < 0.45 || stallCounter < 1
        Offspring = [];
        return;
    end
    if frontState.nnCV < 0.55 && frontState.frontRatio < 1.8
        Offspring = [];
        return;
    end

    pool = [Population,Archive];
    if numel(pool) < 8
        Offspring = [];
        return;
    end

    q = min(max(4,round((0.04 + 0.04 * min(frontState.nnCV,1.5)) * Problem.N)),round(0.14 * Problem.N));
    idx = pickSparseDecisionAnchors(pool,min(q,numel(pool)));
    if isempty(idx)
        Offspring = [];
        return;
    end
    decs = pool.decs;
    D = min(size(decs,2),numel(Problem.lower));
    anchors = decs(idx,1:D);
    q = size(anchors,1);

    fit = CalFitnessFast(pool.objs,0.05);
    [~,order] = sort(fit,'ascend');
    eliteN = min(numel(pool),max(6,round(0.25 * numel(pool))));
    elite = decs(order(1:eliteN),1:D);
    sigma = std(elite,0,1);
    sigma = max(sigma,1e-3 * max(Problem.upper(1:D) - Problem.lower(1:D),1));
    shrink = max(0.025,0.11 - 0.07 * progress);

    donor = elite(randi(eliteN,q,1),:);
    blend = 0.20 + 0.20 * rand(q,1);
    OffDec = anchors + repmat(blend,1,D) .* (donor - anchors) + ...
        randn(q,D) .* repmat(shrink * sigma,q,1);

    mask = rand(q,D) < max(0.18,0.45 - 0.25 * progress);
    OffDec(~mask) = anchors(~mask);
    OffDec = boundReflectLocal(OffDec,Problem.lower(1:D),Problem.upper(1:D));
    Offspring = Problem.Evaluation(OffDec);
end

function idx = pickSparseDecisionAnchors(pool,quota)
    idx = zeros(0,1);
    if quota <= 0 || isempty(pool)
        return;
    end

    Obj = pool.objs;
    Front = NDSort(Obj,1) == 1;
    frontIdx = find(Front);
    if isempty(frontIdx)
        return;
    end
    Obj = Obj(frontIdx,:);
    fmax = max(Obj,[],1);
    fmin = min(Obj,[],1);
    span = fmax - fmin;
    span(span == 0) = 1;
    NormObj = (Obj - fmin) ./ span;
    n = size(NormObj,1);
    if n == 1
        idx = frontIdx;
        return;
    end
    d = pdist2(NormObj,NormObj);
    d(1:n+1:end) = inf;
    sparseScore = min(d,[],2);
    convScore = -sum(NormObj,2);
    score = normalize01(sparseScore) + 0.20 * normalize01(convScore);
    [~,order] = sort(score,'descend');
    idx = frontIdx(order(1:min(quota,numel(order))));
end

function y = normalize01(x)
    xmin = min(x);
    xmax = max(x);
    if xmax - xmin < eps
        y = ones(size(x));
    else
        y = (x - xmin) ./ (xmax - xmin);
    end
end

function X = boundReflectLocal(X,lower,upper)
    Lower = repmat(lower,size(X,1),1);
    Upper = repmat(upper,size(X,1),1);
    span = Upper - Lower;
    valid = span > 0;
    Y = X;
    Y(valid) = mod(X(valid) - Lower(valid), 2 * span(valid));
    over = Y > span & valid;
    Y(over) = 2 * span(over) - Y(over);
    X(valid) = Lower(valid) + Y(valid);
    X(~valid) = Lower(~valid);
end
