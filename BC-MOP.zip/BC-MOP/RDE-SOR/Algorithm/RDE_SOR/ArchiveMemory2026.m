function varargout = ArchiveMemory2026(mode, varargin)
% Maintain an archive and generate archive-guided candidates.
% update  : maintain a long-term archive and estimate its state
% reinject: create a small batch of memory-guided candidates

    switch lower(mode)
        case 'update'
            [varargout{1}, varargout{2}] = updateArchive(varargin{:});
        case 'reinject'
            varargout{1} = reinjectArchive(varargin{:});
        otherwise
            error('ArchiveMemory2026:UnknownMode', 'Unknown mode: %s', mode);
    end
end

function [Archive,state] = updateArchive(Archive,Candidates,capN,epsilon,varargin)
    if isempty(Archive)
        pool = Candidates;
    else
        pool = [Archive,Candidates];
    end
    capN = max(8, capN);
    keepN = min(numel(pool), capN);
    Archive = EnvironmentalSelectionFast(pool,keepN,epsilon);
    state   = estimateArchiveState(Archive);
end

function state = estimateArchiveState(Archive)
    state = struct('size',numel(Archive),'nnCV',0,'nnMean',0,'spread',0);
    if isempty(Archive) || numel(Archive) < 3
        return;
    end

    PopObj = Archive.objs;
    fmax = max(PopObj,[],1);
    fmin = min(PopObj,[],1);
    span = fmax - fmin;
    span(span == 0) = 1;
    PopObj = (PopObj - fmin) ./ span;
    d = pdist2(PopObj,PopObj);
    d(1:size(d,1)+1:end) = inf;
    sd = mink(d,min(3,size(d,2)),2);
    nn = sd(:,1);
    state.nnMean = mean(nn);
    state.nnCV   = std(nn) / max(state.nnMean,eps);
    state.spread = mean(sd(:,min(3,size(sd,2))));
end

function Offspring = reinjectArchive(Problem,Archive,Population,progress,frontState,archiveState,stallCounter)
    if isempty(Archive) || numel(Archive) < 6 || progress < 0.45
        Offspring = [];
        return;
    end
    if nargin < 7
        stallCounter = 0;
    end

    injectBias = max(0, frontState.nnCV - archiveState.nnCV) + 0.35 * max(progress - 0.65,0) + 0.08 * stallCounter;
    if injectBias < 0.10
        Offspring = [];
        return;
    end

    arcDec = Archive.decs;
    arcObj = Archive.objs;
    popDec = Population.decs;
    D = min(size(arcDec,2), size(popDec,2));
    arcDec = arcDec(:,1:D);
    popDec = popDec(:,1:D);

    q = round((0.05 + 0.10 * min(injectBias,0.8)) * Problem.N);
    q = min(max(q,4), max(6, round(0.16 * Problem.N)));

    repIdx = pickRepresentatives(arcObj, min(max(4,round(0.60*q)), numel(Archive)));
    if isempty(repIdx)
        Offspring = [];
        return;
    end

    repDec = arcDec(repIdx,:);
    guide = repDec(randi(size(repDec,1), q, 1),:);
    base  = popDec(randi(size(popDec,1), q, 1),:);
    eliteCenter = mean(repDec,1);

    pull = min(max(0.22 + 0.18 * max(progress - 0.60,0),0.12),0.42);
    mix  = min(max(0.28 + 0.10 * randn(q,1),0.12),0.48);
    local = max(0.03, 0.10 - 0.05 * progress);

    OffDec = base + repmat(mix,1,D) .* (guide - base) + repmat(pull,1,D) .* (repmat(eliteCenter,q,1) - base);

    if progress > 0.60
        sigma = std(repDec,0,1);
        sigma = max(sigma, 1e-3 * max(Problem.upper(1:D) - Problem.lower(1:D), 1));
        OffDec = OffDec + randn(q,D) .* repmat(local * sigma,q,1);
    end

    Lower = repmat(Problem.lower,q,1);
    Upper = repmat(Problem.upper,q,1);
    OffDec = min(max(OffDec,Lower(:,1:D)),Upper(:,1:D));
    Offspring = Problem.Evaluation(OffDec);
end

function idx = pickRepresentatives(PopObj,quota)
    if quota <= 0 || isempty(PopObj)
        idx = zeros(0,1);
        return;
    end

    M = size(PopObj,2);
    fmax = max(PopObj,[],1);
    fmin = min(PopObj,[],1);
    span = fmax - fmin;
    span(span == 0) = 1;
    Y = (PopObj - fmin) ./ span;
    Y = max(Y,eps);
    Y = Y ./ max(sum(Y,2),eps);

    [W,~] = CachedUniformPoint(max(quota,M),M);
    W = max(W,eps);
    W = W ./ vecnorm(W,2,2);
    Ynorm = vecnorm(Y,2,2);
    cosine = (Y * W') ./ max(Ynorm,eps);
    [~,nearest] = max(cosine,[],1);
    idx = unique(nearest(:),'stable');
    if numel(idx) > quota
        idx = idx(1:quota);
    end
end
