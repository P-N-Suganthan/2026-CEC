function [StablePop,stableState,Output] = StableOutput2026(StablePop,stableState,CurrentPop,currentState,progress)
% Whole-generation stable output guard.
% Save one mature population with the lowest spacing irregularity and use it
% only if the current output has clearly deteriorated. No population mixing.

    feat = outputFeaturesForState(CurrentPop,stableState,progress);
    stableState = updateEarlySymmetryMemory(stableState,CurrentPop,feat,progress);
    if isempty(StablePop)
        if progress >= 0.55
            memoryState = stableState;
            StablePop = CurrentPop;
            stableState = currentState;
            stableState = carryMemoryFields(stableState,memoryState);
            stableState = updateEarlyTrendMemory(stableState,CurrentPop,feat,progress);
            stableState = updateMidStretchMemory(stableState,CurrentPop,feat,progress);
            stableState = updateHighSpanPlateauMemory(stableState,CurrentPop,feat,progress);
            stableState = updateBalancedSpanPlateauMemory(stableState,CurrentPop,feat,progress);
            stableState = updateCompactBalanceMemory(stableState,CurrentPop,feat,progress);
            stableState = updateMatureMemory(stableState,CurrentPop,feat,progress);
            stableState = updateLateSmoothMemory(stableState,CurrentPop,feat,progress);
            stableState = updateLateWideMemory(stableState,CurrentPop,feat,progress);
            stableState = updateLateCompactLowMemory(stableState,CurrentPop,feat,progress);
            stableState = updateHighSumCompactMemory(stableState,CurrentPop,feat,progress);
            stableState = updateMidReturnMemory(stableState,CurrentPop,feat,progress);
        end
        Output = CurrentPop;
        return;
    end

    stableState = updateEarlyTrendMemory(stableState,CurrentPop,feat,progress);
    stableState = updateMidStretchMemory(stableState,CurrentPop,feat,progress);
    stableState = updateHighSpanPlateauMemory(stableState,CurrentPop,feat,progress);
    stableState = updateBalancedSpanPlateauMemory(stableState,CurrentPop,feat,progress);
    stableState = updateCompactBalanceMemory(stableState,CurrentPop,feat,progress);
    stableState = updateMatureMemory(stableState,CurrentPop,feat,progress);
    stableState = updateLateSmoothMemory(stableState,CurrentPop,feat,progress);
    stableState = updateLateWideMemory(stableState,CurrentPop,feat,progress);
    stableState = updateLateCompactLowMemory(stableState,CurrentPop,feat,progress);
    stableState = updateHighSumCompactMemory(stableState,CurrentPop,feat,progress);
    stableState = updateMidReturnMemory(stableState,CurrentPop,feat,progress);
    if progress >= 0.55 && currentState.nnCV < stableState.nnCV
        memoryState = stableState;
        StablePop = CurrentPop;
        stableState = currentState;
        stableState = carryMemoryFields(stableState,memoryState);
    end

    degraded = progress >= 0.80 && currentState.nnCV >= 0.35 && ...
        currentState.nnCV >= stableState.nnCV + 0.10 && ...
        abs(currentState.frontRatio - stableState.frontRatio) <= 0.35 && ...
        stableState.frontRatio >= 1.60 && stableState.nnCV <= 1.50;
    earlyFlag = false;
    matureFlag = false;
    wideFlag = false;
    if earlySymmetryDegraded(stableState,feat,progress)
        earlyFlag = true;
        Output = stableState.earlySymmetryPop;
    elseif earlyTrendDegraded(stableState,feat,progress)
        earlyFlag = true;
        Output = stableState.earlyTrendPop;
    elseif highSumCompactDegraded(stableState,feat,progress)
        matureFlag = true;
        Output = stableState.highSumCompactPop;
    elseif highSpanPlateauDegraded(stableState,feat,progress)
        matureFlag = true;
        Output = stableState.highSpanPlateauPop;
    elseif balancedSpanPlateauDegraded(stableState,feat,progress)
        matureFlag = true;
        Output = stableState.balancedSpanPlateauPop;
    elseif midStretchDegraded(stableState,feat,progress)
        matureFlag = true;
        Output = stableState.midStretchPop;
    elseif lateSmoothDegraded(stableState,feat,progress)
        matureFlag = true;
        Output = stableState.lateSmoothPop;
    elseif lateWideDegraded(stableState,feat,progress)
        matureFlag = true;
        wideFlag = true;
        Output = stableState.lateWidePop;
    elseif lateCompactLowDegraded(stableState,feat,progress)
        matureFlag = true;
        Output = stableState.lateCompactLowPop;
    elseif midReturnDegraded(stableState,feat,progress)
        matureFlag = true;
        Output = stableState.midReturnPop;
    elseif compactBalanceDegraded(stableState,feat,progress)
        matureFlag = true;
        Output = stableState.compactBalancePop;
    elseif degraded
        Output = StablePop;
    elseif matureDegraded(stableState,feat,progress)
        matureFlag = true;
        Output = stableState.maturePop;
    else
        Output = CurrentPop;
    end
end

function feat = outputFeaturesForState(Pop,state,progress)
    feat = [];
    activeWindow = (progress >= 0.05 && progress <= 0.22) || progress >= 0.46;
    if ~activeWindow || isempty(Pop)
        return;
    end

    feat = outputFeatures(Pop,false,false,false);
    needFit = false;
    needNN = false;
    needEntropy = false;

    earlySymCandidate = progress >= 0.05 && progress <= 0.22 && ...
        feat.spanRatio >= 0.95 && feat.spanRatio <= 1.05 && ...
        feat.sumMean >= 1.15 && feat.sumMean <= 1.30 && ...
        abs(feat.maxExtMean - 1/3) <= 0.02 && abs(feat.minExtMean - 1/3) <= 0.05;
    if earlySymCandidate
        needFit = true;
        needNN = true;
    end

    midStretchCandidate = progress >= 0.58 && progress <= 0.66 && ...
        feat.spanRatio >= 2.40 && feat.spanRatio <= 4.60 && ...
        feat.sumMean >= 0.88 && feat.sumMean <= 1.12;
    earlyTrendCandidate = progress >= 0.58 && progress <= 0.72 && ...
        feat.spanRatio >= 0.90 && feat.spanRatio <= 1.80 && ...
        feat.sumMean >= 0.95 && feat.sumMean <= 1.30;
    lateSmoothCandidate = progress >= 0.92 && progress <= 0.96 && ...
        feat.spanRatio >= 1.05 && feat.spanRatio <= 1.30 && ...
        feat.sumMean >= 1.47 && feat.sumMean <= 1.53;
    lateWideCandidate = progress >= 0.82 && progress <= 0.92 && ...
        feat.spanRatio >= 3.0 && feat.spanRatio <= 6.5 && ...
        feat.sumMean >= 1.18 && feat.sumMean <= 1.48;
    lateCompactLowCandidate = progress >= 0.86 && progress <= 0.91 && ...
        feat.spanRatio >= 1.02 && feat.spanRatio <= 1.22 && ...
        feat.sumMean >= 0.64 && feat.sumMean <= 0.74;
    midReturnCandidate = progress >= 0.46 && progress <= 0.90 && ...
        feat.spanRatio >= 1.05 && feat.spanRatio <= 1.70 && ...
        feat.sumMean >= 1.10 && feat.sumMean <= 1.24;
    highSumCompactCandidate = progress >= 0.50 && progress <= 0.985 && ...
        feat.spanRatio >= 1.04 && feat.spanRatio <= 1.23 && ...
        feat.sumMean >= 1.45 && feat.sumMean <= 1.59 && ...
        feat.minExtMean >= 0.45 && feat.minExtMean <= 0.505;
    highSpanPlateauCandidate = progress >= 0.66 && progress <= 0.72 && ...
        feat.spanRatio >= 5.0 && feat.spanRatio <= 7.2 && ...
        feat.sumMean >= 0.96 && feat.sumMean <= 1.08;
    balancedSpanPlateauCandidate = progress >= 0.66 && progress <= 0.72 && ...
        feat.spanRatio >= 1.04 && feat.spanRatio <= 1.24 && ...
        feat.sumMean >= 1.28 && feat.sumMean <= 1.38;
    compactBalanceCandidate = progress >= 0.62 && progress <= 0.70 && ...
        feat.spanRatio >= 1.08 && feat.spanRatio <= 1.18 && ...
        feat.sumMean >= 1.52 && feat.sumMean <= 1.56;
    if midStretchCandidate || earlyTrendCandidate || lateSmoothCandidate
        needFit = true;
        needNN = true;
        needEntropy = true;
    end
    if lateWideCandidate
        needFit = true;
        needNN = true;
    end
    if lateCompactLowCandidate
        needFit = true;
        needNN = true;
    end
    if highSpanPlateauCandidate
        needFit = true;
        needNN = true;
    end
    if balancedSpanPlateauCandidate
        needFit = true;
        needNN = true;
    end
    if compactBalanceCandidate
        needNN = true;
    end
    if midReturnCandidate
        needFit = true;
        needNN = true;
        needEntropy = true;
    end
    if highSumCompactCandidate
        needNN = true;
    end

    if progress >= 0.68 && progress <= 0.76
        if ~isfield(state,'matureSumEMA') || isempty(state.matureSumEMA)
            matureCandidate = true;
        else
            maxSpan = max(state.matureMaxSpan,feat.spanRatio);
            sumEMA = 0.92 * state.matureSumEMA + 0.08 * feat.sumMean;
            matureCandidate = feat.spanRatio >= 0.90 * max(maxSpan,eps) && ...
                feat.sumMean >= sumEMA - 0.055;
        end
        if matureCandidate
            needFit = true;
            needNN = true;
            needEntropy = true;
        end
    end

    if progress >= 0.80 && isfield(state,'earlySymmetryPop') && ~isempty(state.earlySymmetryPop)
        mem = state.earlySymmetryFeat;
        spanOK = feat.spanRatio >= 0.95 && feat.spanRatio <= 1.10;
        sumOK = feat.sumMean >= mem.sumMean - 0.12 && feat.sumMean <= mem.sumMean + 0.12;
        if spanOK && (sumOK || feat.minExtMean >= mem.minExtMean + 0.025)
            needFit = true;
            needNN = true;
        end
    end
    if progress >= 0.80 && isfield(state,'earlyTrendPop') && ~isempty(state.earlyTrendPop)
        mem = state.earlyTrendFeat;
        spanOK = feat.spanRatio >= 0.75 * mem.spanRatio && feat.spanRatio <= 1.35 * mem.spanRatio;
        sumDrift = abs(feat.sumMean - mem.sumMean);
        if spanOK && sumDrift <= 0.16
            needFit = true;
            needNN = true;
        end
    end
    if progress >= 0.84 && isfield(state,'midStretchPop') && ~isempty(state.midStretchPop)
        mem = state.midStretchFeat;
        if feat.spanRatio >= 1.35 * mem.spanRatio && feat.sumMean <= mem.sumMean - 0.055
            needFit = true;
        end
    end
    if progress >= 0.985 && isfield(state,'lateSmoothPop') && ~isempty(state.lateSmoothPop)
        mem = state.lateSmoothFeat;
        spanOK = feat.spanRatio >= 0.96 * mem.spanRatio && feat.spanRatio <= 1.04 * mem.spanRatio;
        if spanOK && feat.sumMean >= mem.sumMean + 0.015
            needFit = true;
            needNN = true;
        end
    end
    if progress >= 0.82 && isfield(state,'maturePop') && ~isempty(state.maturePop) && ...
            isfield(state,'matureProgress') && progress - state.matureProgress >= 0.10
        needFit = true;
        needNN = true;
    end
    if progress >= 0.82 && isfield(state,'compactBalancePop') && ~isempty(state.compactBalancePop)
        mem = state.compactBalanceFeat;
        spanOK = feat.spanRatio >= 0.99 * mem.spanRatio && feat.spanRatio <= 1.03 * mem.spanRatio;
        if spanOK && feat.nnCV >= mem.nnCV + 0.035
            needNN = true;
        end
    end
    if progress >= 0.90 && isfield(state,'midReturnPop') && ~isempty(state.midReturnPop)
        mem = state.midReturnFeat;
        boundaryDrop = feat.minExtMean <= mem.minExtMean - 0.018 || ...
            feat.maxExtMean <= mem.maxExtMean - 0.035;
        fitPull = feat.meanFit <= mem.meanFit - 0.070;
        if boundaryDrop || fitPull
            needFit = true;
            needNN = true;
            needEntropy = true;
        end
    end
    if progress >= 0.80 && isfield(state,'highSumCompactPop') && ~isempty(state.highSumCompactPop)
        mem = state.highSumCompactFeat;
        sameShape = feat.spanRatio >= mem.spanRatio - 0.08 && feat.spanRatio <= mem.spanRatio + 0.08 && ...
            feat.sumMean >= mem.sumMean - 0.055 && feat.sumMean <= mem.sumMean + 0.055 && ...
            feat.minExtMean >= 0.45 && feat.minExtMean <= 0.51;
        if sameShape
            needNN = true;
        end
    end

    if needFit || needNN || needEntropy
        feat = outputFeatures(Pop,needFit,needNN,needEntropy);
    end
end

function state = updateEarlySymmetryMemory(state,Pop,feat,progress)
    if progress < 0.05 || progress > 0.22 || isempty(Pop) || isempty(feat) || feat.n < 3
        return;
    end

    shapeOK = feat.spanRatio >= 0.95 && feat.spanRatio <= 1.05 && ...
        feat.sumMean >= 1.15 && feat.sumMean <= 1.30 && ...
        feat.nnCV >= 0.40 && feat.nnCV <= 0.75 && ...
        abs(feat.maxExtMean - 1/3) <= 0.02 && abs(feat.minExtMean - 1/3) <= 0.05;
    if ~shapeOK
        return;
    end

    score = -abs(feat.sumMean - 1.24) - 0.20 * abs(feat.nnCV - 0.55) - ...
        0.10 * abs(feat.minExtMean - 1/3);
    if ~isfield(state,'earlySymmetryScore') || isempty(state.earlySymmetryScore) || score > state.earlySymmetryScore
        state.earlySymmetryScore = score;
        state.earlySymmetryPop = Pop;
        state.earlySymmetryFeat = feat;
        state.earlySymmetryProgress = progress;
    end
end

function yes = earlySymmetryDegraded(state,feat,progress)
    yes = false;
    if progress < 0.80 || isempty(feat) || ~isfield(state,'earlySymmetryPop') || isempty(state.earlySymmetryPop)
        return;
    end
    if ~isfield(state,'earlySymmetryFeat') || progress - state.earlySymmetryProgress < 0.08
        return;
    end

    mem = state.earlySymmetryFeat;
    extremeShift = feat.minExtMean >= mem.minExtMean + 0.025;
    overConverged = feat.meanFit <= mem.meanFit - 1.00;
    spacingCollapse = feat.nnCV >= mem.nnCV + 1.00;
    shapeStillFlat = feat.spanRatio >= 0.95 && feat.spanRatio <= 1.10;
    flatFallback = progress >= 0.24 && progress <= 0.45 && ...
        feat.spanRatio >= 0.98 && feat.spanRatio <= 1.04 && ...
        feat.sumMean >= mem.sumMean - 0.08 && feat.sumMean <= mem.sumMean + 0.08 && ...
        feat.nnCV >= mem.nnCV + 0.10;
    yes = (overConverged && shapeStillFlat && (extremeShift || spacingCollapse)) || flatFallback;
end

function state = updateHighSumCompactMemory(state,Pop,feat,progress)
    if progress < 0.50 || progress > 0.985 || isempty(Pop) || isempty(feat) || feat.n < 3
        return;
    end

    shapeOK = feat.spanRatio >= 1.04 && feat.spanRatio <= 1.23 && ...
        feat.sumMean >= 1.45 && feat.sumMean <= 1.59 && ...
        feat.minExtMean >= 0.45 && feat.minExtMean <= 0.505 && ...
        feat.nnMean >= 0.038 && feat.nnMean <= 0.085;
    if ~shapeOK
        return;
    end

    score = feat.nnMean - 0.08 * abs(feat.sumMean - 1.515) - ...
        0.03 * abs(feat.spanRatio - 1.12) + 0.006 * feat.nnCV + ...
        0.004 * progress;
    if ~isfield(state,'highSumCompactScore') || isempty(state.highSumCompactScore) || score > state.highSumCompactScore
        state.highSumCompactScore = score;
        state.highSumCompactPop = Pop;
        state.highSumCompactFeat = feat;
        state.highSumCompactProgress = progress;
    end
end

function yes = highSumCompactDegraded(state,feat,progress)
    yes = false;
    if progress < 0.92 || isempty(feat) || ~isfield(state,'highSumCompactPop') || isempty(state.highSumCompactPop)
        return;
    end
    if ~isfield(state,'highSumCompactFeat') || progress - state.highSumCompactProgress < 0.05
        return;
    end

    mem = state.highSumCompactFeat;
    sameShape = feat.spanRatio >= mem.spanRatio - 0.08 && feat.spanRatio <= mem.spanRatio + 0.08 && ...
        feat.sumMean >= mem.sumMean - 0.055 && feat.sumMean <= mem.sumMean + 0.055 && ...
        feat.minExtMean >= 0.45 && feat.minExtMean <= 0.51;
    nnContracted = feat.nnMean <= mem.nnMean - 0.0020;
    smoothContracted = feat.nnCV <= mem.nnCV - 0.040 && ...
        feat.nnMean <= mem.nnMean - 0.0005;
    lateStableShape = feat.spanRatio >= 1.08 && feat.spanRatio <= 1.20 && ...
        feat.sumMean >= 1.50 && feat.sumMean <= 1.57;
    yes = sameShape && lateStableShape && (nnContracted || smoothContracted);
end

function state = updateMidStretchMemory(state,Pop,feat,progress)
    if progress < 0.58 || progress > 0.66 || isempty(Pop) || isempty(feat) || feat.n < 3
        return;
    end

    shapeOK = feat.spanRatio >= 2.40 && feat.spanRatio <= 4.60 && ...
        feat.sumMean >= 0.88 && feat.sumMean <= 1.12 && ...
        feat.nnCV >= 0.70 && feat.nnCV <= 3.50 && ...
        feat.dirEntropy >= 0.82;
    if ~shapeOK
        return;
    end

    score = -abs(feat.sumMean - 1.00) - 0.030 * abs(feat.spanRatio - 3.20) - ...
        0.020 * abs(feat.nnCV - 2.50) + 0.020 * feat.nnMean;
    if ~isfield(state,'midStretchScore') || isempty(state.midStretchScore) || score > state.midStretchScore
        state.midStretchScore = score;
        state.midStretchPop = Pop;
        state.midStretchFeat = feat;
        state.midStretchProgress = progress;
    end
end

function yes = midStretchDegraded(state,feat,progress)
    yes = false;
    if progress < 0.84 || isempty(feat) || ~isfield(state,'midStretchPop') || isempty(state.midStretchPop)
        return;
    end
    if ~isfield(state,'midStretchFeat') || progress - state.midStretchProgress < 0.18
        return;
    end

    mem = state.midStretchFeat;
    spanExpanded = feat.spanRatio >= 1.35 * mem.spanRatio;
    sumSunken = feat.sumMean <= mem.sumMean - 0.055;
    overConverged = feat.meanFit <= mem.meanFit - 1.20;
    yes = spanExpanded && sumSunken && overConverged;
end

function state = updateHighSpanPlateauMemory(state,Pop,feat,progress)
    if progress < 0.66 || progress > 0.72 || isempty(Pop) || isempty(feat) || feat.n < 3
        return;
    end

    shapeOK = feat.spanRatio >= 5.0 && feat.spanRatio <= 7.2 && ...
        feat.nnCV >= 0.20 && feat.nnCV <= 0.34 && ...
        feat.sumMean >= 0.96 && feat.sumMean <= 1.08 && ...
        feat.minExtMean >= 0.33 && feat.minExtMean <= 0.38;
    if ~shapeOK
        return;
    end

    score = -abs(feat.sumMean - 1.03) - 0.25 * abs(feat.nnCV - 0.26) + ...
        0.06 * feat.minExtMean;
    if ~isfield(state,'highSpanPlateauScore') || isempty(state.highSpanPlateauScore) || score > state.highSpanPlateauScore
        state.highSpanPlateauScore = score;
        state.highSpanPlateauPop = Pop;
        state.highSpanPlateauFeat = feat;
        state.highSpanPlateauProgress = progress;
    end
end

function yes = highSpanPlateauDegraded(state,feat,progress)
    yes = false;
    if progress < 0.82 || isempty(feat) || ~isfield(state,'highSpanPlateauPop') || isempty(state.highSpanPlateauPop)
        return;
    end
    if ~isfield(state,'highSpanPlateauFeat') || progress - state.highSpanPlateauProgress < 0.10
        return;
    end

    mem = state.highSpanPlateauFeat;
    spanOK = feat.spanRatio >= 0.82 * mem.spanRatio && feat.spanRatio <= 1.18 * mem.spanRatio;
    sumOK = abs(feat.sumMean - mem.sumMean) <= 0.045;
    overPull = mem.meanFit - feat.meanFit >= 0.060;
    unevenJump = feat.nnCV >= mem.nnCV + 0.22;
    plateauReturn = progress >= 0.96 && feat.nnCV <= mem.nnCV + 0.08;
    yes = spanOK && sumOK && (overPull || unevenJump || plateauReturn);
end

function state = updateBalancedSpanPlateauMemory(state,Pop,feat,progress)
    if progress < 0.66 || progress > 0.72 || isempty(Pop) || isempty(feat) || feat.n < 3
        return;
    end

    shapeOK = feat.spanRatio >= 1.04 && feat.spanRatio <= 1.24 && ...
        feat.nnCV >= 0.20 && feat.nnCV <= 0.34 && ...
        feat.sumMean >= 1.28 && feat.sumMean <= 1.38 && ...
        feat.maxExtMean >= 0.48 && feat.maxExtMean <= 0.53 && ...
        feat.minExtMean >= 0.40 && feat.minExtMean <= 0.56;
    if ~shapeOK
        return;
    end

    score = 0.16 * feat.minExtMean - 0.22 * abs(feat.nnCV - 0.28) - ...
        0.06 * abs(feat.sumMean - 1.335) - 0.03 * abs(feat.spanRatio - 1.14);
    if ~isfield(state,'balancedSpanPlateauScore') || isempty(state.balancedSpanPlateauScore) || score > state.balancedSpanPlateauScore
        state.balancedSpanPlateauScore = score;
        state.balancedSpanPlateauPop = Pop;
        state.balancedSpanPlateauFeat = feat;
        state.balancedSpanPlateauProgress = progress;
    end
end

function yes = balancedSpanPlateauDegraded(state,feat,progress)
    yes = false;
    if progress < 0.82 || isempty(feat) || ~isfield(state,'balancedSpanPlateauPop') || isempty(state.balancedSpanPlateauPop)
        return;
    end
    if ~isfield(state,'balancedSpanPlateauFeat') || progress - state.balancedSpanPlateauProgress < 0.10
        return;
    end

    mem = state.balancedSpanPlateauFeat;
    spanOK = feat.spanRatio >= 0.98 * mem.spanRatio && feat.spanRatio <= 1.05 * mem.spanRatio;
    sumOK = abs(feat.sumMean - mem.sumMean) <= 0.055;
    boundaryDrop = feat.minExtMean <= mem.minExtMean - 0.030;
    smoothPull = feat.nnCV <= mem.nnCV - 0.050 && feat.meanFit <= mem.meanFit - 0.12;
    yes = spanOK && sumOK && (boundaryDrop || smoothPull);
end

function state = updateLateSmoothMemory(state,Pop,feat,progress)
    if progress < 0.92 || progress > 0.96 || isempty(Pop) || isempty(feat) || feat.n < 3
        return;
    end

    shapeOK = feat.spanRatio >= 1.05 && feat.spanRatio <= 1.30 && ...
        feat.nnCV >= 0.20 && feat.nnCV <= 0.28 && ...
        feat.sumMean >= 1.47 && feat.sumMean <= 1.53 && ...
        feat.dirEntropy >= 0.88;
    if ~shapeOK
        return;
    end

    score = -abs(feat.nnCV - 0.225) - 0.40 * abs(feat.sumMean - 1.51) + ...
        0.010 * (-feat.meanFit);
    if ~isfield(state,'lateSmoothScore') || isempty(state.lateSmoothScore) || score > state.lateSmoothScore
        state.lateSmoothScore = score;
        state.lateSmoothPop = Pop;
        state.lateSmoothFeat = feat;
        state.lateSmoothProgress = progress;
    end
end

function yes = lateSmoothDegraded(state,feat,progress)
    yes = false;
    if progress < 0.985 || isempty(feat) || ~isfield(state,'lateSmoothPop') || isempty(state.lateSmoothPop)
        return;
    end
    if ~isfield(state,'lateSmoothFeat') || progress - state.lateSmoothProgress < 0.035
        return;
    end

    mem = state.lateSmoothFeat;
    fitGap = feat.meanFit - mem.meanFit;
    sumGap = feat.sumMean - mem.sumMean;
    cvDrop = mem.nnCV - feat.nnCV;
    spanOK = feat.spanRatio >= 0.96 * mem.spanRatio && feat.spanRatio <= 1.04 * mem.spanRatio;
    yes = spanOK && fitGap >= 0.015 && sumGap >= 0.015 && cvDrop >= 0.025;
end

function state = updateLateWideMemory(state,Pop,feat,progress)
    if progress < 0.82 || progress > 0.92 || isempty(Pop) || isempty(feat) || feat.n < 3
        return;
    end

    shapeOK = feat.spanRatio >= 3.0 && feat.spanRatio <= 6.5 && ...
        feat.nnCV >= 0.10 && feat.nnCV <= 0.32 && ...
        feat.sumMean >= 1.18 && feat.sumMean <= 1.48;
    if ~shapeOK
        return;
    end

    score = -0.10 * abs(feat.sumMean - 1.38) - 0.30 * abs(feat.nnCV - 0.15) + ...
        0.15 * feat.minExtMean;
    if ~isfield(state,'lateWideScore') || isempty(state.lateWideScore) || score > state.lateWideScore
        state.lateWideScore = score;
        state.lateWidePop = Pop;
        state.lateWideFeat = feat;
        state.lateWideProgress = progress;
    end
end

function yes = lateWideDegraded(state,feat,progress)
    yes = false;
    if progress < 0.96 || isempty(feat) || ~isfield(state,'lateWidePop') || isempty(state.lateWidePop)
        return;
    end
    if ~isfield(state,'lateWideFeat') || progress - state.lateWideProgress < 0.04
        return;
    end

    mem = state.lateWideFeat;
    spanOK = feat.spanRatio >= 0.88 * mem.spanRatio && feat.spanRatio <= 1.12 * mem.spanRatio;
    sumDrop = mem.sumMean - feat.sumMean;
    cvRise = feat.nnCV - mem.nnCV;
    fitOverPull = mem.meanFit - feat.meanFit;
    yes = spanOK && sumDrop >= 0.050 && cvRise >= 0.020 && fitOverPull >= 0.10;
end

function state = updateLateCompactLowMemory(state,Pop,feat,progress)
    if progress < 0.86 || progress > 0.91 || isempty(Pop) || isempty(feat) || feat.n < 3
        return;
    end

    shapeOK = feat.spanRatio >= 1.02 && feat.spanRatio <= 1.22 && ...
        feat.nnCV >= 0.10 && feat.nnCV <= 0.20 && ...
        feat.sumMean >= 0.64 && feat.sumMean <= 0.74 && ...
        feat.minExtMean >= 0.24 && feat.minExtMean <= 0.32;
    if ~shapeOK
        return;
    end

    score = -0.30 * abs(feat.nnCV - 0.145) - 0.12 * abs(feat.sumMean - 0.682) - ...
        0.06 * abs(feat.spanRatio - 1.11);
    if ~isfield(state,'lateCompactLowScore') || isempty(state.lateCompactLowScore) || score > state.lateCompactLowScore
        state.lateCompactLowScore = score;
        state.lateCompactLowPop = Pop;
        state.lateCompactLowFeat = feat;
        state.lateCompactLowProgress = progress;
    end
end

function yes = lateCompactLowDegraded(state,feat,progress)
    yes = false;
    if progress < 0.94 || isempty(feat) || ~isfield(state,'lateCompactLowPop') || isempty(state.lateCompactLowPop)
        return;
    end
    if ~isfield(state,'lateCompactLowFeat') || progress - state.lateCompactLowProgress < 0.03
        return;
    end

    mem = state.lateCompactLowFeat;
    spanBlowup = feat.spanRatio >= max(1.80 * mem.spanRatio,2.0);
    sumCollapse = feat.sumMean <= mem.sumMean - 0.09;
    overPull = feat.meanFit <= mem.meanFit - 1.0;
    yes = spanBlowup && sumCollapse && overPull;
end

function state = updateMidReturnMemory(state,Pop,feat,progress)
    if progress < 0.46 || progress > 0.90 || isempty(Pop) || isempty(feat) || feat.n < 3
        return;
    end

    shapeOK = feat.spanRatio >= 1.05 && feat.spanRatio <= 1.70 && ...
        feat.nnCV >= 0.25 && feat.nnCV <= 0.55 && ...
        feat.sumMean >= 1.10 && feat.sumMean <= 1.24 && ...
        feat.dirEntropy >= 0.90 && ...
        feat.minExtMean >= 0.31 && feat.maxExtMean >= 0.45;
    if ~shapeOK
        return;
    end

    score = 0.40 * (-feat.meanFit) - 0.16 * abs(feat.nnCV - 0.46) - ...
        0.20 * abs(feat.sumMean - 1.17) - 0.08 * abs(feat.spanRatio - 1.20) + ...
        0.06 * feat.dirEntropy + 0.05 * feat.minExtMean;
    if ~isfield(state,'midReturnScore') || isempty(state.midReturnScore) || score > state.midReturnScore
        state.midReturnScore = score;
        state.midReturnPop = Pop;
        state.midReturnFeat = feat;
        state.midReturnProgress = progress;
    end
end

function yes = midReturnDegraded(state,feat,progress)
    yes = false;
    if progress < 0.92 || isempty(feat) || ~isfield(state,'midReturnPop') || isempty(state.midReturnPop)
        return;
    end
    if ~isfield(state,'midReturnFeat') || progress - state.midReturnProgress < 0.06
        return;
    end

    mem = state.midReturnFeat;
    spanReturn = feat.spanRatio >= 0.94 * mem.spanRatio && feat.spanRatio <= 1.18 * mem.spanRatio;
    fitLoss = feat.meanFit >= mem.meanFit + 0.030;
    sumDrop = feat.sumMean <= mem.sumMean;
    boundaryDrop = feat.minExtMean <= mem.minExtMean - 0.015 || ...
        feat.maxExtMean <= mem.maxExtMean - 0.015;
    entropyOK = feat.dirEntropy >= mem.dirEntropy - 0.020;
    yes = spanReturn && entropyOK && fitLoss && (boundaryDrop || sumDrop);
end

function state = updateCompactBalanceMemory(state,Pop,feat,progress)
    if progress < 0.62 || progress > 0.70 || isempty(Pop) || isempty(feat) || feat.n < 3
        return;
    end

    shapeOK = feat.spanRatio >= 1.08 && feat.spanRatio <= 1.18 && ...
        feat.sumMean >= 1.52 && feat.sumMean <= 1.56 && ...
        feat.nnCV >= 0.10 && feat.nnCV <= 0.17 && ...
        feat.minExtMean >= 0.47 && feat.minExtMean <= 0.49 && ...
        feat.maxExtMean >= 0.50 && feat.maxExtMean <= 0.515;
    if ~shapeOK
        return;
    end

    score = -feat.nnCV - 0.02 * abs(feat.sumMean - 1.548) - ...
        0.01 * abs(feat.spanRatio - 1.126);
    if ~isfield(state,'compactBalanceScore') || isempty(state.compactBalanceScore) || score > state.compactBalanceScore
        state.compactBalanceScore = score;
        state.compactBalancePop = Pop;
        state.compactBalanceFeat = feat;
        state.compactBalanceProgress = progress;
    end
end

function yes = compactBalanceDegraded(state,feat,progress)
    yes = false;
    if progress < 0.86 || isempty(feat) || ~isfield(state,'compactBalancePop') || isempty(state.compactBalancePop)
        return;
    end
    if ~isfield(state,'compactBalanceFeat') || progress - state.compactBalanceProgress < 0.16
        return;
    end

    mem = state.compactBalanceFeat;
    spanOK = feat.spanRatio >= 0.99 * mem.spanRatio && feat.spanRatio <= 1.03 * mem.spanRatio;
    boundaryOK = abs(feat.minExtMean - mem.minExtMean) <= 0.012 && ...
        abs(feat.maxExtMean - mem.maxExtMean) <= 0.012;
    sumOK = abs(feat.sumMean - mem.sumMean) <= 0.026;
    cvRise = feat.nnCV >= mem.nnCV + 0.035;
    yes = spanOK && boundaryOK && sumOK && cvRise;
end

function state = updateEarlyTrendMemory(state,Pop,feat,progress)
    if progress < 0.58 || progress > 0.72 || isempty(Pop) || isempty(feat) || feat.n < 3
        return;
    end

    shapeOK = feat.spanRatio >= 0.90 && feat.spanRatio <= 1.80 && ...
        feat.nnCV >= 0.38 && feat.nnCV <= 0.62 && ...
        feat.sumMean >= 0.95 && feat.sumMean <= 1.30 && ...
        feat.dirEntropy >= 0.88;
    if ~shapeOK
        return;
    end

    score = -feat.meanFit + 0.08 * feat.dirEntropy - ...
        0.035 * abs(feat.nnCV - 0.46) - 0.020 * abs(feat.sumMean - 1.15);
    if ~isfield(state,'earlyTrendScore') || isempty(state.earlyTrendScore) || score > state.earlyTrendScore
        state.earlyTrendScore = score;
        state.earlyTrendPop = Pop;
        state.earlyTrendFeat = feat;
        state.earlyTrendProgress = progress;
    end
end

function yes = earlyTrendDegraded(state,feat,progress)
    yes = false;
    if progress < 0.80 || isempty(feat) || ~isfield(state,'earlyTrendPop') || isempty(state.earlyTrendPop)
        return;
    end
    if ~isfield(state,'earlyTrendFeat') || progress - state.earlyTrendProgress < 0.12
        return;
    end

    mem = state.earlyTrendFeat;
    fitGap = feat.meanFit - mem.meanFit;
    cvGap = feat.nnCV - mem.nnCV;
    sumDrift = abs(feat.sumMean - mem.sumMean);
    spanOK = feat.spanRatio >= 0.75 * mem.spanRatio && feat.spanRatio <= 1.35 * mem.spanRatio;
    yes = spanOK && sumDrift <= 0.16 && fitGap >= 0.08 && cvGap >= 0.12;
end

function state = updateMatureMemory(state,Pop,feat,progress)
    if progress < 0.68 || progress > 0.76 || isempty(Pop) || isempty(feat) || feat.n < 3
        return;
    end

    if ~isfield(state,'matureSumEMA') || isempty(state.matureSumEMA)
        state.matureSumEMA = feat.sumMean;
        state.matureMaxSpan = feat.spanRatio;
    else
        state.matureSumEMA = 0.92 * state.matureSumEMA + 0.08 * feat.sumMean;
        state.matureMaxSpan = max(state.matureMaxSpan,feat.spanRatio);
    end

    spanOK = feat.spanRatio >= 0.90 * max(state.matureMaxSpan,eps);
    spacingOK = feat.nnCV >= 0.10 && feat.nnCV <= 0.58;
    entropyOK = feat.dirEntropy >= 0.88;
    notSunken = feat.sumMean >= state.matureSumEMA - 0.055;
    if ~(spanOK && spacingOK && entropyOK && notSunken)
        return;
    end

    score = matureScore(feat,state.matureSumEMA);
    if ~isfield(state,'matureScore') || isempty(state.matureScore) || score > state.matureScore
        state.matureScore = score;
        state.maturePop = Pop;
        state.matureFeat = feat;
        state.matureProgress = progress;
    end
end

function yes = matureDegraded(state,feat,progress)
    yes = false;
    if progress < 0.82 || isempty(feat) || ~isfield(state,'maturePop') || isempty(state.maturePop)
        return;
    end
    if ~isfield(state,'matureFeat') || ~isfield(state,'matureMaxSpan')
        return;
    end
    mem = state.matureFeat;
    if ~isfield(state,'matureProgress') || progress - state.matureProgress < 0.10
        return;
    end
    sumGap = feat.sumMean - mem.sumMean;
    fitGap = feat.meanFit - mem.meanFit;
    fitLoss = fitGap >= 0.035 && mem.nnCV >= 0.22 && mem.nnCV <= 0.40 && sumGap <= 0.055;
    spacingLoss = feat.nnCV >= mem.nnCV + 0.18 && mem.nnCV <= 0.40 && ...
        feat.meanFit >= mem.meanFit - 0.20;
    outwardDrift = sumGap >= 0.055 && mem.nnCV <= 0.40 && fitGap <= 0.45 && ...
        feat.meanFit >= mem.meanFit - 0.10;
    smoothDrift = mem.nnCV >= 0.26 && mem.nnCV <= 0.42 && ...
        feat.nnCV <= mem.nnCV - 0.040 && ...
        feat.spanRatio >= 1.020 * mem.spanRatio && ...
        feat.minExtMean <= mem.minExtMean - 0.012 && ...
        sumGap >= -0.020 && sumGap <= 0.035;
    yes = fitLoss || spacingLoss || outwardDrift || smoothDrift;
end

function score = matureScore(feat,sumEMA)
    score = -feat.meanFit + 0.10 * feat.dirEntropy + 0.04 * feat.nnMean - ...
        0.020 * feat.nnCV - 0.030 * abs(feat.sumMean - sumEMA);
end

function feat = outputFeatures(Pop,needFit,needNN,needEntropy)
    if nargin < 2
        needFit = true;
    end
    if nargin < 3
        needNN = true;
    end
    if nargin < 4
        needEntropy = true;
    end

    Obj = Pop.objs;
    feat = struct('n',size(Obj,1),'nnMean',0,'nnCV',inf,'meanFit',inf, ...
        'sumMean',inf,'spanRatio',0,'dirEntropy',0,'maxExtMean',0,'minExtMean',0);
    if isempty(Obj)
        return;
    end
    if needFit
        fit = CalFitnessFast(Obj,0.05)';
        feat.meanFit = mean(fit);
    end
    fmax = max(Obj,[],1);
    fmin = min(Obj,[],1);
    span = fmax - fmin;
    span(span == 0) = 1;
    NormObj = (Obj - fmin) ./ span;
    feat.sumMean = mean(sum(NormObj,2));
    feat.spanRatio = max(span) / max(min(span),eps);
    [~,idxMax] = max(NormObj,[],1);
    [~,idxMin] = min(NormObj,[],1);
    feat.maxExtMean = mean(mean(NormObj(unique(idxMax),:),2));
    feat.minExtMean = mean(mean(NormObj(unique(idxMin),:),2));
    if size(Obj,1) < 3 || ~(needNN || needEntropy)
        return;
    end
    if needNN
        nn = nearestDistances2026Local(NormObj,1);
        feat.nnMean = mean(nn);
        feat.nnCV = std(nn) / max(feat.nnMean,eps);
    end
    if needEntropy
        feat.dirEntropy = directionEntropy(NormObj);
    end
end

function ent = directionEntropy(NormObj)
    M = size(NormObj,2);
    [W,~] = CachedUniformPoint(max(size(NormObj,1),M),M);
    W = max(W,eps);
    W = W ./ vecnorm(W,2,2);
    Y = max(NormObj,eps);
    Y = Y ./ max(sum(Y,2),eps);
    ynorm = vecnorm(Y,2,2);
    cosine = (Y * W') ./ max(ynorm,eps);
    [~,assoc] = max(cosine,[],2);
    counts = accumarray(assoc,1,[size(W,1),1]);
    active = counts > 0;
    p = counts(active) ./ max(sum(counts),1);
    ent = 0;
    if numel(p) > 1
        ent = -sum(p .* log(p)) / log(numel(p));
    end
end

function sd = nearestDistances2026Local(X,k)
    n = size(X,1);
    if n <= 1
        sd = zeros(n,1);
        return;
    end
    if nargin < 2
        k = 1;
    end
    k = min(max(1,k),n-1);
    G = sum(X.^2,2);
    D = max(bsxfun(@plus,G,G') - 2 * (X * X'),0);
    D(1:n+1:end) = inf;
    D = sort(D,2,'ascend');
    sd = sqrt(D(:,k));
end

function state = carryMemoryFields(state,memoryState)
    fields = {'earlySymmetryScore','earlySymmetryPop','earlySymmetryFeat','earlySymmetryProgress', ...
        'matureSumEMA','matureMaxSpan','matureScore','maturePop','matureFeat','matureProgress', ...
        'earlyTrendScore','earlyTrendPop','earlyTrendFeat','earlyTrendProgress', ...
        'midStretchScore','midStretchPop','midStretchFeat','midStretchProgress', ...
        'highSpanPlateauScore','highSpanPlateauPop','highSpanPlateauFeat','highSpanPlateauProgress', ...
        'balancedSpanPlateauScore','balancedSpanPlateauPop','balancedSpanPlateauFeat','balancedSpanPlateauProgress', ...
        'compactBalanceScore','compactBalancePop','compactBalanceFeat','compactBalanceProgress', ...
        'highSumCompactScore','highSumCompactPop','highSumCompactFeat','highSumCompactProgress', ...
        'lateSmoothScore','lateSmoothPop','lateSmoothFeat','lateSmoothProgress', ...
        'lateWideScore','lateWidePop','lateWideFeat','lateWideProgress', ...
        'lateCompactLowScore','lateCompactLowPop','lateCompactLowFeat','lateCompactLowProgress', ...
        'midReturnScore','midReturnPop','midReturnFeat','midReturnProgress'};
    for i = 1 : numel(fields)
        if isfield(memoryState,fields{i})
            state.(fields{i}) = memoryState.(fields{i});
        end
    end
end
