function [PC,nND,state] = SelectionDirectionalIndicator(PC,N,progress,epsilon)
% Direction-aware indicator selection.
% Each active direction keeps its best representative, then indicator quality
% and distance-to-selected fill the rest of the population.

    if nargin < 3 || isempty(progress)
        progress = 0;
    end
    if nargin < 4 || isempty(epsilon)
        epsilon = 0.05;
    end

    PC = PC(NDSort(PC.objs,1) == 1);
    nND = length(PC);
    RawObj = PC.objs;
    [NormObj,DirObj] = normalizeObjectives(RawObj);
    state = makeStateFromNorm(NormObj,N,progress);
    if nND <= N
        return;
    end

    M = size(NormObj,2);
    [W,~] = CachedUniformPoint(max(N,M),M);
    W = max(W,eps);
    W = W ./ vecnorm(W,2,2);

    dirNorm = vecnorm(DirObj,2,2);
    cosine = (DirObj * W') ./ max(dirNorm,eps);
    [bestCos,assoc] = max(cosine,[],2);
    angleScore = normalize01(bestCos);

    fitness = CalFitnessFast(RawObj,epsilon)';
    fitScore = normalize01(fitness);
    convScore = normalize01(max(sum(NormObj,2)) - sum(NormObj,2));

    keep = false(nND,1);
    [~,idxMin] = min(NormObj,[],1);
    [~,idxMax] = max(NormObj,[],1);
    keep(unique([idxMin(:);idxMax(:)])) = true;

    dirWeight = 0.44 + 0.18 * min(max(state.nnCV - 0.25,0),1);
    fitWeight = 0.40 + 0.14 * max(progress - 0.55,0);
    convWeight = max(0.08, 1 - dirWeight - fitWeight);
    repScore = fitWeight * fitScore + dirWeight * angleScore + convWeight * convScore;

    activeDirs = unique(assoc(:))';
    for d = activeDirs
        candidates = find(assoc == d);
        [~,best] = max(repScore(candidates));
        keep(candidates(best)) = true;
    end

    if nnz(keep) > N
        PC = SelectionExactFast(PC(keep),N,true);
        nND = length(PC);
        return;
    end

    while nnz(keep) < min(N,nND)
        candidates = find(~keep);
        if isempty(candidates)
            break;
        end
        if any(keep)
            d2keep = min(pdist2(NormObj(candidates,:),NormObj(keep,:)),[],2);
        else
            d2keep = ones(numel(candidates),1);
        end
        fillScore = 0.46 * fitScore(candidates) + 0.34 * normalize01(d2keep) + ...
            0.12 * convScore(candidates) + 0.08 * angleScore(candidates);
        [~,best] = max(fillScore);
        keep(candidates(best)) = true;
    end

    PC = PC(keep);
    nND = length(PC);
    if nND > N
        PC = SelectionExactFast(PC,N,true);
        nND = length(PC);
    end
end

function state = makeStateFromNorm(NormObj,N,progress)
    n = size(NormObj,1);
    state = struct('frontRatio', n/max(N,1), 'nnCV', 0, 'nnMean', 0, ...
        'keepRatio', 1, 'needsPolish', false);
    if n < 3
        return;
    end
    d = pdist2(NormObj,NormObj);
    d(1:size(d,1)+1:end) = inf;
    nn = min(d,[],2);
    state.nnMean = mean(nn);
    state.nnCV = std(nn) / max(state.nnMean,eps);
    state.needsPolish = progress >= 0.90 && (state.nnCV >= 0.50 || n >= 1.8 * N);
end

function [NormObj,DirObj] = normalizeObjectives(PopObj)
    fmax = max(PopObj,[],1);
    fmin = min(PopObj,[],1);
    span = fmax - fmin;
    span(span == 0) = 1;
    NormObj = (PopObj - fmin) ./ span;
    DirObj = max(NormObj,eps);
    DirObj = DirObj ./ max(sum(DirObj,2),eps);
end

function y = normalize01(x)
    if isempty(x)
        y = x;
        return;
    end
    xmin = min(x);
    xmax = max(x);
    if xmax - xmin < eps
        y = ones(size(x));
    else
        y = (x - xmin) ./ (xmax - xmin);
    end
end
