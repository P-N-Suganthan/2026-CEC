function Offspring = OperatorDE2026(Problem, Population, fitness)

    if isa(Population(1), 'SOLUTION')
        evaluated = true;
        Popu = Population.decs;
    else
        evaluated = false;
        Popu = Population;
    end

    [~, index] = sort(fitness, 'ascend');
    OffDec = DE2026(Popu, Problem, index);
    if evaluated
        Offspring = Problem.Evaluation(OffDec);
    else
        Offspring = OffDec;
    end
end

function Offspring = DE2026(Popu, Problem, index)
    [N, D] = size(Popu);
    progress = Problem.FE / Problem.maxFE;

    pRate = max(0.10, 0.18 - 0.08 * progress);
    P = max(round(pRate * N), 2);
    pbest = Popu(index(randi(P, N, 1)), :);

    FmBase  = [0.6, 0.8, 1.0];
    CRmBase = [0.1, 0.2, 1.0];
    F  = FmBase(randi(numel(FmBase), N, 1))';
    CR = CRmBase(randi(numel(CRmBase), N, 1))';
    F  = F + 0.08 * (0.5 - progress) + 0.03 * randn(N,1);
    CR = CR + 0.05 * (0.35 - progress) + 0.03 * randn(N,1);
    F  = min(max(F, 0.45), 1.00);
    CR = min(max(CR, 0.05), 1.00);

    Fm = repmat(F, 1, D);
    [r1, r2] = gnR1R2Fast(N);
    V = Popu + Fm .* (pbest - Popu + Popu(r1,:) - Popu(r2,:));

    jrand = randi(D, N, 1);
    CrossMask = rand(N,D) < repmat(CR,1,D);
    CrossMask(sub2ind([N,D], (1:N)', jrand)) = true;

    Offspring = Popu;
    Offspring(CrossMask) = V(CrossMask);

    perturbProb = max(0.08, 0.20 - 0.08 * progress);
    PerturbMask = rand(N,D) < perturbProb;
    if any(PerturbMask(:))
        scale = max(0.08, 0.20 - 0.06 * progress);
        Offspring(PerturbMask) = cauchyrnd(Offspring(PerturbMask), scale);
    end

    Lower = repmat(Problem.lower, N, 1);
    Upper = repmat(Problem.upper, N, 1);
    Offspring = min(max(Offspring, Lower), Upper);
end

function [r1, r2] = gnR1R2Fast(N)
    base = (1:N)';
    r1 = randi(N, N, 1);
    conflict = r1 == base;
    while any(conflict)
        r1(conflict) = randi(N, sum(conflict), 1);
        conflict = r1 == base;
    end

    r2 = randi(N, N, 1);
    conflict = (r2 == base) | (r2 == r1);
    while any(conflict)
        r2(conflict) = randi(N, sum(conflict), 1);
        conflict = (r2 == base) | (r2 == r1);
    end
end
