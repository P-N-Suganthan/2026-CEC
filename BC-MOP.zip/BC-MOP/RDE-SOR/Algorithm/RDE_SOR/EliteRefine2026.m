function Offspring = EliteRefine2026(Problem,Population,Archive,epsilon,progress,frontState,archiveState)
% Late-stage low-frequency elite refinement.
% It strengthens convergence using a small number of archive-guided DE moves
% while keeping a few direction representatives to avoid collapsing coverage.

    if nargin < 6 || isempty(frontState)
        frontState = struct('nnCV',0.4,'frontRatio',1.0);
    end
    if nargin < 7
        archiveState = [];
    end
    if isempty(Population)
        Offspring = [];
        return;
    end

    pool = [Population,Archive];
    if numel(pool) < 6
        Offspring = [];
        return;
    end

    fit = CalFitnessFast(pool.objs,epsilon);
    [~,order] = sort(fit,'ascend');
    order = order(:);
    decs = pool.decs;
    objs = pool.objs;
    Npool = size(decs,1);
    if ~isempty(archiveState) && isfield(archiveState,'fragmentIdx') && ~isempty(archiveState.fragmentIdx)
        archiveOffset = numel(Population);
        fragPool = archiveOffset + archiveState.fragmentIdx(:);
        fragPool = fragPool(fragPool >= 1 & fragPool <= Npool);
        if ~isempty(fragPool)
            order = unique([fragPool(:); order(:)],'stable');
        end
    end
    refQuota = max(2, round(0.18 * Problem.N * min(1, max(frontState.nnCV - 0.15, 0))));
    refIdx = pickRefIndex(objs(order,:), min(refQuota,numel(order)));
    refIdx = order(refIdx);

    eliteCap = min(Npool, max(12, round((0.28 + 0.16 * max(progress - 0.68, 0)) * Problem.N)));
    eliteIdx = unique([order(1:eliteCap); refIdx(:)],'stable');
    eliteDec = decs(eliteIdx,:);

    qTotal = round((0.12 + 0.12 * max(progress - 0.70, 0) + 0.10 * max(0.42 - frontState.nnCV, 0)) * Problem.N);
    qTotal = min(max(qTotal,8), max(10, round(0.28 * Problem.N)));
    qTotal = min(qTotal, max(8,size(eliteDec,1)));
    qDE = max(4, round(0.60 * qTotal));
    qGS = max(4, qTotal - qDE);

    topFocus = min(size(eliteDec,1), max(4, round(0.55 * qDE)));
    targetIdx = [randi(topFocus,ceil(qDE/2),1); randi(size(eliteDec,1),floor(qDE/2),1)];
    target = eliteDec(targetIdx,:);

    guideIdx = randi(size(eliteDec,1), qDE, 1);
    guide = eliteDec(guideIdx,:);

    r1 = eliteDec(randi(size(eliteDec,1), qDE, 1),:);
    r2 = decs(randi(Npool, qDE, 1),:);
    eliteCenter = mean(eliteDec(1:min(size(eliteDec,1),max(3,round(0.25*size(eliteDec,1)))),:),1);

    D = min([size(target,2), size(guide,2), size(r1,2), size(r2,2), ...
        size(eliteCenter,2), size(eliteDec,2), numel(Problem.lower), numel(Problem.upper)]);
    target = target(:,1:D);
    guide = guide(:,1:D);
    r1 = r1(:,1:D);
    r2 = r2(:,1:D);
    eliteCenter = eliteCenter(1:D);
    eliteDec = eliteDec(:,1:D);

    Fmain = min(max(0.34 + 0.08 * randn(qDE,1),0.18),0.55);
    Fdiff = min(max(0.18 + 0.06 * frontState.nnCV + 0.05 * randn(qDE,1),0.08),0.35);
    Fpull = min(max(0.16 + 0.20 * max(0.45 - frontState.nnCV,0),0.08),0.28);

    V = target + repmat(Fmain,1,D) .* (guide - target) + ...
        repmat(Fdiff,1,D) .* (r1 - r2) + ...
        repmat(Fpull,1,D) .* (repmat(eliteCenter,qDE,1) - target);

    CR = min(max(0.82 + 0.05 * randn(qDE,1),0.62),0.96);
    jrand = randi(D,qDE,1);
    CrossMask = rand(qDE,D) < repmat(CR,1,D);
    CrossMask(sub2ind([qDE,D],(1:qDE)',jrand)) = true;

    OffDec = target;
    OffDec(CrossMask) = V(CrossMask);

    % Diagonal Gaussian local sampling around elite/reference anchors.
    focusN = min(size(eliteDec,1), max(6, round(0.35 * size(eliteDec,1))));
    focusDec = eliteDec(1:focusN,:);
    sigma = std(focusDec,0,1);
    sigma = max(sigma, 1e-3 * max(Problem.upper(1:D) - Problem.lower(1:D), 1));
    shrink = max(0.04, 0.16 - 0.10 * progress);
    sigma = shrink * sigma;

    gsTop = min(size(eliteDec,1), max(4, round(0.40 * qGS)));
    gsIdx = [randi(gsTop,ceil(qGS/2),1); randi(size(eliteDec,1),floor(qGS/2),1)];
    base = eliteDec(gsIdx,:);
    centerPull = repmat(0.18 * max(0.45 - frontState.nnCV,0),qGS,D) .* (repmat(eliteCenter,qGS,1) - base);
    GaussianOff = base + randn(qGS,D) .* repmat(sigma,qGS,1) + centerPull;

    Lower = repmat(Problem.lower(1:D),qTotal,1);
    Upper = repmat(Problem.upper(1:D),qTotal,1);
    OffDec = min(max(OffDec,Lower(1:qDE,:)),Upper(1:qDE,:));
    GaussianOff = min(max(GaussianOff,Lower(1:qGS,:)),Upper(1:qGS,:));
    Offspring = Problem.Evaluation([OffDec;GaussianOff]);
end

function idx = pickRefIndex(PopObj,quota)
    if quota <= 0 || isempty(PopObj)
        idx = zeros(0,1);
        return;
    end
    M = size(PopObj,2);
    fmax = max(PopObj,[],1);
    fmin = min(PopObj,[],1);
    span = fmax - fmin;
    span(span == 0) = 1;
    Y = (PopObj - fmin) ./ span;
    Y = max(Y,eps);
    Y = Y ./ max(sum(Y,2),eps);

    [W,~] = CachedUniformPoint(max(quota,M),M);
    W = max(W,eps);
    W = W ./ vecnorm(W,2,2);
    Ynorm = vecnorm(Y,2,2);
    cosine = (Y * W') ./ max(Ynorm,eps);
    [~,nearest] = max(cosine,[],1);
    idx = unique(nearest(:),'stable');
    if numel(idx) > quota
        idx = idx(1:quota);
    end
end
