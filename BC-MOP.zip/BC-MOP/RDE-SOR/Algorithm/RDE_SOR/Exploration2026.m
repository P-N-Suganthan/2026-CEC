function Offspring = Exploration2026(Problem,Population,Popul,nND,N)

    if isempty(Population) || numel(Population) < 3 || isempty(Popul)
        Offspring = [];
        return;
    end

    PCObj  = Population.objs;
    NPCObj = Popul.objs;

    fmax = max(PCObj,[],1);
    fmin = min(PCObj,[],1);
    span = fmax - fmin;
    span(span == 0) = 1;
    PCObj  = (PCObj - fmin) ./ span;
    NPCObj = (NPCObj - fmin) ./ span;

    d = pdist2(PCObj,PCObj);
    d(1:size(d,1)+1:end) = inf;
    sd = mink(d,min(3,size(d,2)),2);
    r0 = mean(sd(:,min(3,size(sd,2))));
    r  = max(eps, nND / N * r0);

    cover = pdist2(PCObj,NPCObj);
    sparseMask = sum(cover <= r,2) <= 1;
    S = find(sparseMask);
    if isempty(S)
        Offspring = [];
        return;
    end

    progress = Problem.FE / Problem.maxFE;
    capRatio = max(0.50, 0.95 - 0.30 * progress);
    maxExplore = max(1, round(capRatio * Problem.N));
    if numel(S) > maxExplore
        S = S(randperm(numel(S), maxExplore));
    end

    MatingPool = randi(length(Population),1,length(S));
    Offspring  = OperatorDEhalf2026(Problem,Population([S',MatingPool]));
end
