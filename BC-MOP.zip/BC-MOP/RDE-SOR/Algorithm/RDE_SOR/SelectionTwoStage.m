function [PC,nND,state] = SelectionTwoStage(PC,N,progress,epsilon)
% Two-stage first-front maintenance.
% Fast pre-pruning reduces the candidate set before exact first-front
% deletion is applied to the reduced subset.

    if nargin < 3 || isempty(progress)
        progress = 0;
    end
    if nargin < 4 || isempty(epsilon)
        epsilon = 0.05;
    end

    PC = PC(NDSort(PC.objs,1) == 1);
    nND = length(PC);
    state = struct('frontRatio', nND / max(N,1), 'nnCV', 0, 'nnMean', 0, ...
        'keepRatio', 1, 'needsPolish', false);
    if nND <= N
        return;
    end

    [state,PCObj,sd] = estimateFrontState(PC.objs,N,progress);
    preRatio = 1.45 + 0.16 * min(state.frontRatio,3.0) + 0.32 * min(state.nnCV,1.0) ...
        + 0.10 * progress;
    preRatio = min(2.10, max(1.55, preRatio));
    preN = min(nND, max(round(preRatio * N), N + 24));
    state.keepRatio = preN / nND;
    state.needsPolish = progress >= 0.90 && (state.nnCV >= 0.55 || state.frontRatio >= 1.9);
    if nND > preN
        PC = preReduceFirstFront(PC, PCObj, sd, preN, progress, epsilon, state);
    end

    [PC,nND] = SelectionExactFast(PC,N,true);
end

function PC = preReduceFirstFront(PC,PCObj,sd,keepN,progress,epsilon,state)
    nND   = size(PCObj,1);
    M     = size(PCObj,2);

    % Preserve objective-wise extreme points.
    extreme = false(nND,1);
    [~,idxMin] = min(PCObj,[],1);
    [~,idxMax] = max(PCObj,[],1);
    extreme(unique([idxMin(:); idxMax(:)])) = true;

    k = min(3,size(sd,2));
    nnScore = mean(sd(:,1:k),2);
    crowdScore = sum(sd(:,1:min(M,size(sd,2))),2);
    convScore = 1 - mean(PCObj,2);
    score = 0.62 * nnScore + 0.23 * crowdScore + 0.15 * convScore;

    keepMask = extreme;
    remaining = keepN - nnz(keepMask);
    if remaining > 0
        candidates = find(~keepMask);
        refFrac = 0.10 + 0.16 * min(max(state.nnCV - 0.25, 0), 1) + ...
            0.06 * min(max(state.frontRatio - 1.2, 0), 1);
        refQuota = min(remaining, max(0, round(refFrac * keepN)));
        if refQuota > 0 && numel(candidates) > 0
            refPicked = pickReferenceRepresentatives(PCObj(candidates,:), refQuota, M);
            keepMask(candidates(refPicked)) = true;
            remaining = keepN - nnz(keepMask);
        end
        convFrac = min(0.10, max(0, 0.10 * (progress - 0.60) + 0.08 * (0.45 - state.nnCV)));
        convQuota = min(remaining, max(0, round(convFrac * keepN)));
        if convQuota > 0
            candidates = find(~keepMask);
            [~,order] = sort(convScore(candidates),'descend');
            keepMask(candidates(order(1:min(convQuota,numel(order))))) = true;
            remaining = keepN - nnz(keepMask);
        end
        if remaining > 0
            candidates = find(~keepMask);
            [~,order] = sort(score(candidates),'descend');
            keepMask(candidates(order(1:min(remaining,numel(order))))) = true;
        end
    end

    PC = PC(keepMask);
end

function [state,PCObj,sd] = estimateFrontState(rawObj,N,progress)
    nND = size(rawObj,1);
    fmax = max(rawObj,[],1);
    fmin = min(rawObj,[],1);
    span = fmax - fmin;
    span(span == 0) = 1;
    PCObj = (rawObj - fmin) ./ span;

    sd = nearestDistances(PCObj,min(3,size(PCObj,2)));
    nn = sd(:,1);
    nnMean = mean(nn);
    nnCV = std(nn) / max(nnMean,eps);

    state = struct();
    state.frontRatio = nND / max(N,1);
    state.nnCV = nnCV;
    state.nnMean = nnMean;
    state.keepRatio = 1;
    state.sumMean = mean(sum(PCObj,2));
    state.spanRatio = max(span) / max(min(span),eps);
    state.needsPolish = progress >= 0.90 && (nnCV >= 0.55 || nND >= 1.9 * N);
end

function sd = nearestDistances(PCObj,k)
    nND = size(PCObj,1);
    d = pdist2(PCObj,PCObj);
    d(1:nND+1:end) = inf;
    sd = mink(d,k,2);
end

function picked = pickReferenceRepresentatives(PopObj,quota,M)
    if isempty(PopObj) || quota <= 0
        picked = zeros(0,1);
        return;
    end

    [W,~] = CachedUniformPoint(max(quota,M),M);
    W = max(W,eps);
    W = W ./ vecnorm(W,2,2);

    Y = max(PopObj,eps);
    Y = Y ./ max(sum(Y,2),eps);
    Ynorm = vecnorm(Y,2,2);
    cosine = (Y * W') ./ max(Ynorm,eps);
    proj = cosine;
    [~,nearest] = max(proj,[],1);
    picked = unique(nearest(:),'stable');

    if numel(picked) > quota
        picked = picked(1:quota);
    end
end
