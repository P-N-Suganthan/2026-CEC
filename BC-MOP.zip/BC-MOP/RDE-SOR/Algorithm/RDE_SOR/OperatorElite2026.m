function Offspring = OperatorElite2026(Problem, Population, Archive, fitness, progress, frontState, archiveState)
% A convergence-oriented operator for the elite branch.
% It uses archive leaders and a center-pulling term to intensify late-stage search.

    if isa(Population(1), 'SOLUTION')
        PopDec = Population.decs;
    else
        PopDec = Population;
    end

    if nargin < 3 || isempty(Archive)
        arcDec = PopDec;
    else
        arcDec = Archive.decs;
    end
    if nargin < 4 || isempty(fitness)
        fitness = 1:size(PopDec,1);
    end
    if nargin < 5 || isempty(progress)
        progress = 0.5;
    end
    if nargin < 6 || isempty(frontState)
        frontState = struct('nnCV',0.4,'frontRatio',1.2);
    end
    if nargin < 7
        archiveState = [];
    end

    [~,index] = sort(fitness,'ascend');
    OffDec = eliteDE(PopDec, arcDec, Problem, index, progress, frontState, archiveState);
    Offspring = Problem.Evaluation(OffDec);
end

function OffDec = eliteDE(PopDec, arcDec, Problem, index, progress, frontState, archiveState)
    [N,D] = size(PopDec);
    arcN = size(arcDec,1);

    if ~isempty(archiveState) && isfield(archiveState,'fragmentIdx') && ~isempty(archiveState.fragmentIdx)
        fragIdx = archiveState.fragmentIdx(:);
        fragIdx = fragIdx(fragIdx >= 1 & fragIdx <= arcN);
        if ~isempty(fragIdx)
            arcDec = arcDec(fragIdx,:);
            arcN = size(arcDec,1);
        end
    end

    pRate = max(0.06, 0.14 - 0.07 * progress);
    P = max(2, round(pRate * N));
    pbest = PopDec(index(randi(P, N, 1)), :);

    topArc = min(arcN, max(4, round((0.18 + 0.10 * progress) * arcN)));
    arcGuide = arcDec(randi(topArc, N, 1), :);
    arcCenter = mean(arcDec(1:topArc,:),1);

    Fmain = min(max(0.38 + 0.06 * randn(N,1), 0.18), 0.58);
    Fdiff = min(max(0.14 + 0.05 * randn(N,1), 0.05), 0.28);
    Fpull = min(max(0.18 + 0.20 * max(0.45 - frontState.nnCV,0), 0.10), 0.34);
    Farch = min(max(0.18 + 0.12 * progress, 0.10), 0.36);

    [r1,r2] = gnR1R2Elite(N);
    V = PopDec ...
        + repmat(Fmain,1,D) .* (pbest - PopDec) ...
        + repmat(Farch,1,D) .* (arcGuide - PopDec) ...
        + repmat(Fdiff,1,D) .* (PopDec(r1,:) - PopDec(r2,:)) ...
        + repmat(Fpull,1,D) .* (repmat(arcCenter,N,1) - PopDec);

    CR = min(max(0.86 - 0.12 * max(frontState.nnCV - 0.35,0) + 0.04 * randn(N,1), 0.60), 0.98);
    jrand = randi(D,N,1);
    CrossMask = rand(N,D) < repmat(CR,1,D);
    CrossMask(sub2ind([N,D],(1:N)',jrand)) = true;

    OffDec = PopDec;
    OffDec(CrossMask) = V(CrossMask);

    if progress > 0.75
        sigma = 0.03 + 0.03 * max(0.35 - frontState.nnCV,0);
        localMask = rand(N,D) < (0.06 + 0.10 * max(progress - 0.75,0));
        if any(localMask(:))
            OffDec(localMask) = OffDec(localMask) + sigma * randn(nnz(localMask),1);
        end
    end

    Lower = repmat(Problem.lower,N,1);
    Upper = repmat(Problem.upper,N,1);
    OffDec = min(max(OffDec,Lower),Upper);
end

function [r1,r2] = gnR1R2Elite(N)
    base = (1:N)';
    r1 = randi(N,N,1);
    c = r1 == base;
    while any(c)
        r1(c) = randi(N,sum(c),1);
        c = r1 == base;
    end
    r2 = randi(N,N,1);
    c = (r2 == base) | (r2 == r1);
    while any(c)
        r2(c) = randi(N,sum(c),1);
        c = (r2 == base) | (r2 == r1);
    end
end
