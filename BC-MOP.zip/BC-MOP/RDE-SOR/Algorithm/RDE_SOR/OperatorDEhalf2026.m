function Offspring = OperatorDEhalf2026(Problem,Population)

    if isa(Population(1),'SOLUTION')
        evaluated = true;
        Population = Population.decs;
    else
        evaluated = false;
    end

    Popu  = Population(1:floor(end/2),:);
    PopuG = Population(floor(end/2)+1:floor(end/2)*2,:);
    OffDec = DEhalf2026(Popu,PopuG,Problem);
    if evaluated
        Offspring = Problem.Evaluation(OffDec);
    else
        Offspring = OffDec;
    end
end

function Offspring = DEhalf2026(Popu,PopuG,Problem)
    [N,D] = size(Popu);
    progress = Problem.FE / Problem.maxFE;

    F  = min(max(0.60 + 0.10 * randn(N,1), 0.25), 0.95);
    CR = min(max(0.55 - 0.20 * progress + 0.08 * randn(N,1), 0.05), 0.95);

    r1 = randperm(N,N);
    V = Popu + repmat(F,1,D) .* (Popu(r1,:) - PopuG);

    jrand = randi(D, N, 1);
    CrossMask = rand(N,D) < repmat(CR,1,D);
    CrossMask(sub2ind([N,D], (1:N)', jrand)) = true;

    Offspring = Popu;
    Offspring(CrossMask) = V(CrossMask);
    Lower = repmat(Problem.lower,N,1);
    Upper = repmat(Problem.upper,N,1);
    Offspring = min(max(Offspring, Lower), Upper);
end
