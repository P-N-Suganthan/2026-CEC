function Population = EnvironmentalSelectionFast(Population,N,kappa)

    Next = 1 : length(Population);
    [Fitness,I,C] = CalFitnessFast(Population.objs,kappa);
    while length(Next) > N
        [~,x] = min(Fitness(Next));
        Fitness = Fitness + exp(-I(Next(x),:)./C/kappa);
        Next(x) = [];
    end
    Population = Population(Next);
end
