function Output = OutputSidecar2026(MainOutput,Pool,N,progress,epsilon)
%OUTPUTSIDECAR2026 Output-only sidecar.
% A conservative state gate may report an early Union/TwoStage front when
% spacing is still sufficiently uneven. The sidecar never feeds back into
% the search and restores RNG state.

    Output = MainOutput;
    if progress > 0.494 || isempty(Pool)
        return;
    end
    if nargin < 5 || isempty(epsilon)
        epsilon = 0.05;
    end

    rngState = rng;
    [SideOutput,~,~] = SelectionRootUnion(Pool,N,progress,epsilon);
    rng(rngState);
    if isempty(SideOutput)
        return;
    end

    sideFeat = sidecarFeatures(SideOutput);
    if ~isempty(sideFeat) && sideFeat.nnCV > 0.345
        Output = SideOutput;
    end
end

function feat = sidecarFeatures(Pop)
    feat = [];
    if isempty(Pop)
        return;
    end
    Pop = Pop.best;
    Obj = Pop.objs;
    n = size(Obj,1);
    if n < 3
        return;
    end

    fmax = max(Obj,[],1);
    fmin = min(Obj,[],1);
    span = fmax - fmin;
    span(span == 0) = 1;
    NormObj = (Obj - fmin) ./ span;
    nn = nearestDistances2026Local(NormObj,1);
    feat = struct('nnCV',std(nn) / max(mean(nn),eps));
end

function sd = nearestDistances2026Local(X,k)
    n = size(X,1);
    if n <= 1
        sd = zeros(n,1);
        return;
    end
    if nargin < 2
        k = 1;
    end
    k = min(max(1,k),n-1);
    G = sum(X.^2,2);
    D = max(bsxfun(@plus,G,G') - 2 * (X * X'),0);
    D(1:n+1:end) = inf;
    D = sort(D,2,'ascend');
    sd = sqrt(D(:,k));
end
