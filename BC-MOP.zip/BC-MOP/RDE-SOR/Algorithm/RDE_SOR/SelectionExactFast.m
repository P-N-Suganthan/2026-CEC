function [PC,nND] = SelectionExactFast(PC,N,presorted)
% Maintain the first nondominated front using incremental updates.

    if nargin < 3 || isempty(presorted)
        presorted = false;
    end
    if ~presorted
        PC = PC(NDSort(PC.objs,1) == 1);
    end
    PC    = PC(randperm(length(PC)));
    PCObj = PC.objs;
    nND   = length(PC);

    if nND <= N
        return;
    end

    fmax = max(PCObj,[],1);
    fmin = min(PCObj,[],1);
    span = fmax - fmin;
    span(span == 0) = 1;
    PCObj = (PCObj - repmat(fmin,nND,1)) ./ repmat(span,nND,1);

    d = pdist2(PCObj,PCObj);
    d(1:nND+1:end) = inf;
    sd = mink(d,min(3,size(d,2)),2);
    r = mean(sd(:,min(3,size(sd,2))));
    R = min(d ./ max(r,eps),1);

    alive = true(nND,1);
    zeroCount = sum(R == 0,2);
    logR = log(max(R,realmin('double')));
    logProd = sum(logR,2);

    aliveCount = nND;
    while aliveCount > N
        prodR = zeros(nND,1);
        nzMask = zeroCount == 0;
        prodR(nzMask) = exp(logProd(nzMask));
        score = 1 - prodR;
        score(~alive) = -inf;
        [~,worst] = max(score);

        alive(worst) = false;
        aliveCount = aliveCount - 1;

        col = R(:,worst);
        zeroCount = zeroCount - (col == 0);
        logProd = logProd - logR(:,worst);
        zeroCount(~alive) = 1;
        logProd(~alive) = -inf;
    end

    PC = PC(alive);
    nND = length(PC);
end
