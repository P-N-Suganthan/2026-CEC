function [PC,nND,state] = SelectionRootUnion(PC,N,progress,epsilon)
% Early selector ensemble.
% Directional selection supplies coarse front-shape correction, while
% two-stage selection maintains local coverage. The final N are chosen from their union
% without spending extra function evaluations.

    if nargin < 3 || isempty(progress)
        progress = 0;
    end
    if nargin < 4 || isempty(epsilon)
        epsilon = 0.05;
    end

    if progress <= 0.42
        [DirPC,~,dirState] = SelectionDirectionalIndicator(PC,N,progress,epsilon);
        [BcePC,~,state]    = SelectionTwoStage(PC,N,progress,epsilon);
        unionPC = [DirPC,BcePC];
        if length(unionPC) > N
            [PC,nND] = SelectionExactFast(unionPC,N);
        else
            PC = unionPC;
            nND = length(PC);
        end
        state.dirNNCV = dirState.nnCV;
        state.selector = 2;
    else
        [PC,nND,state] = SelectionTwoStage(PC,N,progress,epsilon);
        state.selector = 0;
    end
end
