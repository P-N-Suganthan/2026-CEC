function [W,Nout] = CachedUniformPoint(N,M)
% Cached deterministic NBI reference points.
% UniformPoint(N,M) is deterministic for the default NBI method and is used
% repeatedly with the same small set of N/M values inside selection.

    persistent cache
    key = sprintf('N%d_M%d',N,M);
    if isempty(cache) || ~isfield(cache,key)
        [W,Nout] = UniformPoint(N,M);
        cache.(key) = struct('W',W,'N',Nout);
    else
        item = cache.(key);
        W = item.W;
        Nout = item.N;
    end
end
