function [PC,nND,state] = SelectionRootAdaptive(PC,N,progress,epsilon)
% Use directional selection early and two-stage selection later.

    if nargin < 3 || isempty(progress)
        progress = 0;
    end
    if progress <= 0.42
        [PC,nND,state] = SelectionDirectionalIndicator(PC,N,progress,epsilon);
    else
        [PC,nND,state] = SelectionTwoStage(PC,N,progress,epsilon);
    end
end
