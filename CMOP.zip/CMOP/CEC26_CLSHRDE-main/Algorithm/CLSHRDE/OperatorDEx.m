function [Trial , flag] = OperatorDEx(Problem,r0,p1,r1,r2,Mid,Worst,fit_r1,fit_r2,flag, successMW, successR)

%% Parameter setting
Fm = [0.6,0.8,1.0];
CRm=[0.1,0.2,1.0];
index = randi([1,length(Fm)],Problem.N,1);
F = Fm(index);
F = F';
F2 = F;
pos = fit_r1 > fit_r2;
F2(pos) = -1 * F(pos);
F = F(:, ones(1,Problem.D));
F2 = F2(:, ones(1,Problem.D));

index = randi([1,length(CRm)],Problem.N,1);
Cr = CRm(index);
Cr = Cr';
%% Differental evolution

Site = rand(Problem.N,Problem.D) < repmat(Cr,1,Problem.D);

t = Problem.FE / Problem.maxFE;
smoothstep = t * t * (3 - 2 * t);
alpha = 0.2 + 0.8*(1 - smoothstep);

adv = (successR - successMW) ./ (successR + successMW + 1e-12);
k = 0.40;
w = 0.1 + 0.9*smoothstep^2;

conf = min(1, (successR + successMW) / 0.2);
bias = k * adv * w * conf;
bias = max(min(bias, 0.20), -0.20);

p0   = 0.20;   
ampT = 0.10;   

pMin = 0.05;
pMax = 0.45;

base = p0 + ampT*(smoothstep - 0.5);   % 前期略低、后期略高，但围绕0.2
%bias  = 0.05 * adv * smoothstep;       % 成功率偏置：越到后期越相信成功率(乘 s)

pChoose = base + bias;
pChoose = min(max(pChoose, pMin), pMax);

S = successMW + successR;  % 0~1左右
CauchyMin = 0.02;
CauchyMax = 0.20;
S_th = 0.25;

stall = max(0, S_th - S) / S_th;   % S 低于阈值才触发
expl = 1 - smoothstep;          % 0~1
factor = 0.7*expl + 0.3*stall;  % 保证0~1

CauchyNum = CauchyMin + (CauchyMax - CauchyMin) * factor;
CauchyNum = min(max(CauchyNum, CauchyMin), CauchyMax);

choose = rand(Problem.N,1) < pChoose;

TrialMW = r0;
TrialR = r0;

TrialMW(Site) = r0(Site) + F(Site) .* (p1(Site) - r0(Site)) + F2(Site) .* (Mid(Site) - Worst(Site));
TrialR(Site) = r0(Site) + F(Site) .* (p1(Site) - r0(Site)) + alpha * F2(Site) .* (r1(Site) - r2(Site));

for i = 1:Problem.N
    if choose(i)
        Trial(i,:) = TrialR(i,:);
        flag(i)    = 1;   % Rand
    else
        
        Trial(i,:) = TrialMW(i,:);
        flag(i)    = 0;   % MW
    end
end

Trial = min(max(Trial, Problem.lower), Problem.upper);
Trial(Site & Trial < Problem.lower) = (r0(Site & Trial < Problem.lower) + Problem.lower(1)) / 2;
Trial(Site & Trial > Problem.upper) = (r0(Site & Trial > Problem.upper) + Problem.upper(1)) / 2;

pPert = 0.2;    
pertMask = rand(Problem.N,1) < pPert;

range = (Problem.upper - Problem.lower);                 
scale = CauchyNum .* range;       

for i = find(pertMask)'
    idx = ~Site(i,:);
    Trial(i,idx) = cauchyrnd(r0(i,idx), scale(idx));
end

Trial = min(max(Trial, Problem.lower), Problem.upper);

end