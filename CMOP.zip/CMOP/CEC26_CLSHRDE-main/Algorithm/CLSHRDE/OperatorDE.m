function [ Offspring,successMW,successR] = OperatorDE(Population, popsize, Problem, Fitness,flag, successMW, successR)

[~, sorted_index] = sort(Fitness, 'ascend');
r0 = 1 : popsize;
[r1, r2] = gnR1R2(popsize, popsize, r0);
fit_r1 = Fitness(r1);
fit_r2 = Fitness(r2);

pNP = max(floor(popsize * (1-0.99*Problem.FE/Problem.maxFE)), 2);
wNP = max(floor(popsize * (1-0.99*Problem.FE/Problem.maxFE)), 2);
midRatio = 0.2;                    
midWidth = max(1, floor(popsize * midRatio / 2));

randindex = ceil(rand(1, popsize) .* pNP);
midCenter = ceil(popsize / 2);
randindex = max(1, randindex);
midL = max(1, midCenter - midWidth);
midR = min(popsize, midCenter + midWidth);

pbest = Population(sorted_index(randindex));     %精英种群

worstPool = sorted_index(end - wNP + 1 : end);   %乐色种群
Worst = Population(worstPool(randi(wNP, 1, popsize)));

midPool = sorted_index(midL : midR);             %普通人种群
Mid = Population(midPool(randi(numel(midPool), 1, popsize)));

[NewDec , flag] = OperatorDEx(Problem,Population(r0).decs,pbest.decs,Population(r1).decs,Population(r2).decs,Mid.decs,Worst.decs,fit_r1,fit_r2,flag,successMW,successR);
Offspring = Problem.Evaluation(NewDec);
Fitchild  = CalFitness(Offspring.objs, Offspring.cons);
FitParent = Fitness(r0);
improved  = Fitchild < FitParent;

CauchyNum = Fitchild / 200;

tryMW = sum(flag == 0);
tryR  = sum(flag == 1);
succMW = sum(improved(flag == 0));
succR  = sum(improved(flag == 1));

rateMW_gen = succMW / (tryMW + 1e-12);
rateR_gen  = succR  / (tryR  + 1e-12);

% -------- EWMA（核心）--------
persistent mw_ewma r_ewma %mw_hist r_hist
if isempty(mw_ewma)
    mw_ewma = 0.5;
    r_ewma  = 0.5;

    % 分数阶平滑的历史长度 L
    %L = 20;
    %mw_hist = 0.5*ones(L,1);   % 初始都填 0.5
    %r_hist  = 0.5*ones(L,1);

end

lambda = 0.25;  
mw_ewma = (1 - lambda) * mw_ewma + lambda * rateMW_gen;
r_ewma  = (1 - lambda) * r_ewma  + lambda * rateR_gen;

%更新长记忆序列
% 这里假设 mw_hist/r_hist 是 [最旧 ... 最新] 的列向量
%L = numel(mw_hist);
%mw_hist = [mw_hist(2:end); rateMW_gen];
%r_hist  = [r_hist(2:end);  rateR_gen ];

% 幂律权重：越新的权重大，越旧的权重小，且是 k^{-alpha} 形式
%alpha = 0.5;                         % 分数阶阶数，0<alpha<1
%idx   = (L:-1:1)';                   % idx= [L,L-1,...,1] 让“最新”权重最大
%w     = idx.^(-alpha);
%w     = w / sum(w);                  % 归一化

%mw_frac = sum(mw_hist .* w);         % 分数阶长记忆平滑
%r_frac  = sum(r_hist  .* w);

% 融合短记忆 + 长记忆 ====
%beta = 0.5;   % 短记忆（EWMA）占比，0.5 表示 EWMA 和 分数阶各占一半
%successMW = beta * mw_ewma + (1-beta) * mw_frac;
%successR  = beta * r_ewma  + (1-beta) * r_frac;

successMW = mw_ewma;
successR  = r_ewma;

if mod(Problem.FE, 1000) == 0
    fprintf('[FE=%6d] MW=%.3f R=%.3f | ewMW=%.3f ewR=%.3f', ...
        Problem.FE, rateMW_gen, rateR_gen, mw_ewma, r_ewma);
end

end

function [r1, r2] = gnR1R2(NP1, NP2, r0)
NP0 = length(r0);
r1 = zeros(1, NP0);
r2 = zeros(1, NP0);

for i = 1:NP0
    pool = setdiff(1:NP1, r0(i));
    r1(i) = pool(randi(length(pool)));
end

for i = 1:NP0
    pool = setdiff(1:NP2, [r0(i), r1(i)]);
    r2(i) = pool(randi(length(pool)));
end

end
