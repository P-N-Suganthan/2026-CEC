% =========================================================================
% Project: CEC26_CLSHRDE
% Algorithm: CLSHRDE
% Competition: CEC 2026
%
% Description:
%   This file is the main entry point for running the CLSHRDE algorithm.
%   The algorithm is designed for constrained multi-objective optimization
%   problems (CMOPs).
%
% Author:
%   JIN CHENNUO
%
% Affiliation:
%   Hirosaki University
%   Intelligent Computing and Optimization Laboratory
%
% Research Direction:
%   Constrained Multi-objective Optimization Problems (CMOPs)
%
% Contact:
%   h26ms411@hirosaki-u.ac.jp
%
% License:
%   MIT License
%
% Copyright:
%   Copyright (c) 2026 JIN CHENNUO
% =========================================================================

classdef CLSHRDE < ALGORITHM

    methods
        function main(Algorithm,Problem)

            %% Generate random population
            Population = Problem.Initialization();
            cons = Population.cons;
            cons(cons <= 0)=0;
            conss = sum(cons,2);
            epsilon0 = max(conss);
            if epsilon0 == 0
                epsilon0 = 1;
            end
            Fitness = CalFitness_E(Population.objs,Population.cons,epsilon0);

            flag = zeros(100,1);
            successMW = 0.5;
            successR = 0.5;


            %% Optimization
            while Algorithm.NotTerminated(Population)

                cp=(-log(epsilon0)-6)/log(1-0.5);
                epsilon = epsilon0*(1-Problem.FE/Problem.maxFE)^cp;
                
                [Offspring, successMW, successR] = OperatorDE(Population, Problem.N, Problem, Fitness,flag, successMW, successR);
                

                [Population,Fitness] = Improve_E_EnvironmentalSelection([Population,Offspring],Problem.N,epsilon);
                

            end
        end
    end
end

